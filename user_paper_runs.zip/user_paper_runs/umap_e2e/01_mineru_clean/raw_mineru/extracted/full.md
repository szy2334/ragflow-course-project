# Multimodal Emotion Recognition with Missing Modality via a Unified Multi-task Pre-training Framework

Ziyi Li   
liziyi@sjtu.edu.cn   
School of Computer Science,   
Shanghai Jiao Tong Unversity   
Shanghai, China   
Wei-Long Zheng\*   
weilong@sjtu.edu.cn   
School of Computer Science,   
Shanghai Jiao Tong Unversity   
Shanghai, China   
Bao-Liang Lu\*   
bllu@sjtu.edu.cn   
School of Computer Science,   
Shanghai Jiao Tong Unversity   
Shanghai, China

## Abstract

Multimodal emotion recognition based on physiological signals faces the challenge of missing modality due to issues such as inaccurate signal synchronization and inadequate device contact. Existing methods either require additional generative modules to handle missing modalities, leading to extra computational overhead, or fail to effectively capture both modality-specific and joint representation. In contrast, we propose a Unified Multi-task Pretraining (UMAP) framework based on the mixture of experts structure. Our approach offers two key advantages: (1) It retains a joint structure while flexibly handling both unimodal and multimodal inputs by selecting lightweight modality experts and shared experts, thus preserving both modality-specific features and joint multimodal information. 2) Three pre-training tasks—contrastive learning, modality matching, and modality generation—are integrated into UMAP through different attention masks, enhancing the model's ability to adapt to both complete and incomplete modalities during fine-tuning. Comprehensive experiments conducted on three benchmark datasets demonstrate that UMAP achieves state-of-the-art (SOTA) performance, both in multimodal scenarios and in cases where any modality is missing. The code is available at https://github.com/iiieeeve/UMAP.

## CCS Concepts

• Computing methodologies → Artificial intelligence; • Humancentered computing → HCI design and evaluation methods.

## Keywords

Missing Modality, Emotion Recognition, EEG, Eye Movement, Pretraining

## ACM Reference Format:

Ziyi Li, Wei-Long Zheng, and Bao-Liang Lu. 2025. Multimodal Emotion Recognition with Missing Modality via a Unified Multi-task Pre-training Framework. In Proceedings of the 33rd ACM International Conference on Multimedia (MM '25), October 27–31, 2025, Dublin, Ireland. ACM, New York, NY, USA, 9 pages. https://doi.org/10.1145/3746027.3755459

## 1 Introduction

Emotions are complex responses that involve changes in experience, behavior, and physiology [24]. As such, multimodal emotion recognition, which combines features from different modalities, typically outperforms unimodal approaches [4]. Researches have demonstrated the effectiveness of combining signals such as facial expression [25], speech [1], and text [21] for emotion recognition tasks. In contrast to these signals, physiological signals directly reflect an individual's internal emotional state, which makes them less susceptible to manipulation [9]. This has spurred growing interest in utilizing physiological signals, including electroencephalography (EEG) [15], electrocardiogram (ECG) [6], and eye movement signals [17] for emotion recognition tasks. Among these signals, EEG and eye movement data exhibit complementary characteristics for emotion recognition, leading to improved classification accuracy when combined in a multimodal framework.[5, 20, 37, 38].

However, the collection of multimodal physiological signals often faces the challenge of missing modalities. For example, in EEG and eye movement data collection, poor device contact, significant participant movement, lack of gaze on the screen, or inaccurate synchronization between the two signals can all lead to missing modalities. Many multimodal algorithms require the completeness of all modalities during both training and testing phases, which limits their practical applicability [27]. Consequently, adapting multimodal algorithms to handle missing modalities holds significant practical value for multimodal emotion recognition with physiological signals [32].

Generative models that synthesize joint representation or features for missing modalities are a promising approach. For example, Wang et al. [30] utilized a diffusion model to generate features for missing modalities. However, these models add extra generative modules, which are not utilized when all modalities are present, leading to unnecessary computational overhead and reducing their practical applicability [30]. In contrast, Zhao et al. [36] focused on learning joint representation, but their approach overlooks modality-specific features. To address this, Wang et al. [27] and Xu et al. [32] applied expert models for each modality. Similarly, in the self-supervised learning domain, Jiang et al. [7] pre-trained expert models for each modality based on the CLIP framework. However, these models fail to effectively integrate information across modalities. While they perform well when some modalities are missing, their effectiveness decreases when all modalities are present. To overcome this, some models [8, 35] combine modality-specific experts with a joint-modality encoder. However, these methods fail to account for the importance of shared experts and do not fully leverage multi-task self-supervised learning.

![](images/764c32281cfa9b65c0a29a26b90eed16dd4f6aff45f205e5cc1aa78492ef21e3.jpg)  
Figure 1: a) The multimodal and multi-task pre-training of UMAP. b) Fine-tuning when modality B is missing: simply deactivate the expert module for modality B.

To overcome the limitations of previous approaches, we propose a Unified Multi-task Pre-training (UMAP) framework based on the mixture of experts structure. As shown in Figure 1, UMAP offers a unified framework that adapts to both unimodal and multimodal inputs. After multimodal and multi-task pre-training, UMAP can be fine-tuned for each subject based on their specific modality requirements. In cases of missing modalities, fine-tuning is performed by deactivating the experts for the absent modalities. UMAP provides two key advantages: 1) Structural Advantage: It integrates modality-specific experts with shared experts to capture both modality-specific information and joint representation. These experts are constructed as lightweight components using the Feed-Forward Network (FFN) layer within the Transformer architecture. Additionally, effective modality fusion is achieved through weight-sharing self-attention layers and a fusion Transformer layer. 2) Pre-training Task Advantage: UMAP facilitates modality interaction across three pre-training tasks—contrastive learning, modality matching, and modality generation—by using different attention masks in weight-sharing self-attention layers. Ablation experiments confirm the effectiveness of each task.

The main contributions of this paper are as follows:

• We integrate modality experts with shared experts to capture both modality-specific and joint representation, enabling UMAP to handle both complete and missing modality scenarios flexibly.

• We integrate three pre-training tasks—contrastive learning, modality matching, and modality generation—through different attention masks in weight-sharing self-attention layers, enhancing modality interaction and enabling the model to learn robust, generalized representation that adapt to diverse input conditions.

• We conduct comprehensive experiments to demonstrate that our proposed UMAP achieves SOTA performance with both complete and missing modalities, while also validating the effectiveness of each component.

## 2 Related Work

## 2.1 Multimodal Algorithms

Multimodal signals provide diverse and complementary information for emotion recognition models [10]. Compared to unimodal approaches, multimodal methods often achieve superior performance by integrating features from different modalities [4]. Among these, EEG and eye movement signals are widely adopted due to their complementary discriminative properties. Specifically, Zheng et al. [20, 37, 38] demonstrated that EEG signals excel in classifying happy emotions, while eye movement signals are more effective for fear recognition—a finding validated across multiple datasets and algorithms [5, 17, 19]. To leverage this complementarity, Zheng et al. [34, 38] employed a Bimodal Deep Autoencoder (BDA) to extract shared representations from EEG and eye movement data. Further advancements include the work of Liu et al. [18] and Lan et al. [11], who proposed Deep Canonical Correlation Analysis with an Attention Mechanism (DCCA-AM) to maximize nonlinear correlations between the two modalities.

In recent years, many studies have proposed Transformer-based [26] multimodal approaches for emotion recognition. For instance, Wang et al. [29] proposed the Emotion Transformer Fusion (ETF) algorithm, which employs two independent Transformer encoders to process EEG and eye movement signals separately, followed by attention-based fusion of their representations. Ma et al. [21] introduced a Self-Distillation Transformer (SDT) model, utilizing both intra- and inter-modal Transformer for each modality, with fused outputs generated through a hierarchical gating module. Hybrid approaches combining Convolutional Network (CNN) with Transformer have also emerged. For instance, VigilanceNet [2] uses CNN to extract electrooculogram (EOG) features and Transformer for EEG features, integrating them via a cross-attention mechanism. Similarly, Wu et al. [31] developed a Transformer-Based Self-Supervised Multimodal Representation Learning (TSSL) framework, where CNN-extracted multimodal features are concatenated before being fed into a Transformer. However, these multimodal methods necessitate the use of all modality data during both training and testing. When a modality is missing, it can only be addressed through zero padding, which impacts the model's performance.

## 2.2 Multimodal Algorithms with Missing Modality

Generative algorithms can address missing modalities by synthesizing either the features of the missing modalities or joint representation. These methods typically add additional generative modules to the existing multimodal algorithms. For example, Yan et al. [33] extended multimodal Restricted Boltzmann Machines (RBM) by incorporating Generative Adversarial Network (GAN) to generate joint representation. Incomplete Multimodality-Diffused emotion recognition (IMDer) model adds a diffusion module to cross-attention Transformer to generate unimodal features [30]. However, these additional generative modules do not function when all modalities are present, introducing extra computational overhead and potentially affecting their practical applicability [30].

In contrast, Missing Modality Imagination Network (MMIN) [36] uses a Cascade Residual Autoencoder (CRA) to reconstruct joint representation when modalities are missing, but neglects modality-specific representation. To address this issue, Mixture of Modality Knowledge Experts (MoMKE) [32] extracts modalityspecific information through modality experts and introduces a Soft Router to fuse the outputs of all experts. CLIP-based models [23] pre-train each expert model using contrastive learning. However, these methods struggle to effectively integrate joint information across modalities. As shown in Table 1, although CLIP demonstrates strong robustness to missing modalities, its performance is comparatively limited when processing complete multimodal inputs Therefore, some models combine modality-specific experts with a joint-modality encoder [16]. Multimodal Learning with Alternating Unimodal Adaptation (MLA) [35] enhances the modality encoder by introducing a shared head and gradient modification to capture cross-modal information. Multimodal Adaptive Emotion Transformer (MAET) [8] combines modality experts with a unified self-attention layer to extract shared information. However, they overlook the importance of shared experts. Furthermore, none of these models fully leverage multi-task self-supervised learning to improve performance.

![](images/075238abf590ed721d691c67b10ae75d36ecfd9a838d10b5e0fdf86c97e652d1.jpg)  
Figure 2: The pre-training stage of UMAP, where green represents fusion modules, and blue and pink denote the EEG and eye movement modules, respectively. The color scheme in the other figures is consistent with this one. UMAP employs three pre-training tasks, each utilizing different attention masks in the weight-sharing self-attention blocks, as shown in the right part of the figure. These tasks are optimized simultaneously through four forward passes, with modality generation tasks requiring one pass for each modality. Data from both modalities are initially passed through the patch embedding blocks and weight-sharing self-attention blocks. EEG embeddings are then directed to the EEG expert and the shared expert, while eye movement embeddings are fed into the EYE expert and the shared expert. The outputs of modality expert and shared expert are fused by modality-specific gate (EEG and EYE gates). After passing through Ne layers of identical operations, the embeddings of both modalities are concatenated and fed into $N _ { f }$ Transformer layers with the same weight-sharing self-attention blocks.

## 3 Methodology

## 3.1 Overall Architecture

As shown in Figure 1, UMAP is a two-stage model. In the first stage, the multimodal and multi-task pre-training phase (Figure

2), a unified, general model is trained using all available unlabeled data from complete modalities. The training set comprises training data from all subjects. In the second stage, the fine-tuning phase (Figure 3), the model is fine-tuned for each subject to meet their specific modality requirements (whether modalities are missing or complete). When all modalities are available, fine-tuning proceeds directly. In cases of missing modalities, the expert model for the absent modality is deactivated, and fine-tuning is performed with the remaining available modalities. UMAP will be introduced in three parts: model structure, multimodal and multi-task pre-training and fine-tuning with missing or complete modalities.

## 3.2 Model Structure

An input EEG G is denoted as a sequence of $\{ { g _ { c l s } , g _ { 1 } , . . . , g _ { s } } \}$ , where $\pmb { g } _ { c l s }$ is the [CLS] token of EEG, and s is the number of sequences. An input eye movement M is denoted as a sequence of $\{ \pmb { m } _ { c l s } , \pmb { m } _ { 1 } , . . . , \pmb { m } _ { s } \}$ where $m _ { c l s }$ is the [CLS] token of eye movement.

3.2.1 Patch Embedding. The inputs G and M are first mapped to a common feature dimension d by linear projection. Then, a learnable EEG type encoding $t _ { g } \in \mathbb { R } ^ { d }$ and a learnable positional encoding $P _ { g } \in \mathbb { R } ^ { ( s + 1 ) \times d }$ are added to G, while a learnable eye movement type encoding $t _ { m } \in \mathbb { R } ^ { d }$ and a learnable positional encoding $P _ { m } \in$ $\dot { \mathbb { R } } ^ { ( s + 1 ) \times d }$ are added to M.

3.2.2 Weight-sharing Self Attention Layer. As in [12], the weights of self-attention are shared between EEG and eye movement to enhance modality interaction. The multihead attention is computed as in [26]:

$$
\begin{array} { r l r } { A } & { { } = } & { c o n c a t ( A _ { 1 } , . . . , A _ { h } ) W ^ { o } , } \end{array}
$$

$$
\begin{array} { r c l } { { A _ { i } } } & { { = } } & { { s o f t m a x ( \frac { Q _ { i } K _ { i } ^ { T } } { \sqrt { d } } ) V _ { i } , } } \end{array}\tag{1}
$$

(2)

with $W ^ { o } \in \mathbb { R } ^ { d \times d }$ , h representing the number of heads, and $Q _ { i } , K _ { i } , V _ { i }$ being computed by linear projections $W _ { i } ^ { Q } , W _ { i } ^ { K } , W _ { i } ^ { V } \in \mathbb { R } ^ { d \times d / h }$ of the input sequences, respectively. It is important to note that, as depicted in Figure 2, the interaction requirements between sequences differ across pre-training tasks. Consequently, each pre-training task is associated with a distinct attention mask, which will be further explained in Section 3.3.

3.2.3 Expert Models. We utilize the FFN layer in the Transformer as a lightweight expert model. Specifically, we design modalityspecific experts that process inputs from their respective modalities, and a shared expert that processes inputs from all modalities. The FFN layer consists of two linear transformations with a GELU activation function in between, where the input and output dimensions are d and the inner-layer dimensionality is $4 \times d .$ Subsequently, the outputs from both modality-specific and shared experts are integrated via modality-specific gates. Taking EEG as an example, the EEG expert output is denoted as $G ^ { e }$ We slice the EEG-corresponding sequences from the output of the shared expert to form $Z ^ { g } .$ The output $G ^ { o }$ of EEG gate is:

$$
\begin{array} { r l r } { \alpha _ { 1 } , \alpha _ { 2 } } & { { } = } & { G ^ { e } W ^ { f } , Z ^ { g } W ^ { f } , } \end{array}\tag{3}
$$

$$
\begin{array} { c c l } { \displaystyle { w _ { 1 } , w _ { 2 } } } & { \displaystyle { = } } & { \displaystyle { \frac { e ^ { \alpha _ { 1 } } } { e ^ { \alpha _ { 1 } } + e ^ { \alpha _ { 2 } } } , \frac { e ^ { \alpha _ { 2 } } } { e ^ { \alpha _ { 1 } } + e ^ { \alpha _ { 2 } } } , } } \end{array}\tag{4}
$$

$$
\begin{array} { r l r } { G ^ { o } } & { { } = } & { w _ { 1 } G ^ { e } + w _ { 2 } Z ^ { g } , } \end{array}\tag{5}
$$

where $W ^ { f } \in \mathbb { R } ^ { d \times 1 }$ represents the attention weight.

3.2.4 Fusion Transformer. Inspired by [28], we add a Fusion Transformer with the same weight-sharing self-attention blocks to enable full modality interaction. As shown in Figure 2, the outputs of the modality-specific gates, $G ^ { o }$ and $M ^ { o }$ , are concatenated and passed through the Transformer. The final embedding R is denoted as a sequence of $\{ r _ { c l s } ^ { g } , r _ { 1 } ^ { g } , . . . , r _ { s } ^ { g } , r _ { c l s } ^ { m } , \boldsymbol { r } _ { 1 } ^ { m } , . . . , r _ { s } ^ { m } \}$ , where $r _ { c l s } ^ { g }$ and $r _ { c l s } ^ { m }$ are the [CLS] tokens of EEG and eye movement, respectively.

## 3.3 Multimodal and Multi-task Pre-training

Three pre-training objectives are optimized simultaneously, all sharing the same input format and model parameters. As a result, each data pair requires four forward passes (with modality generation tasks requiring one pass for each modality). To accommodate varying modality interaction needs, the modules and attention masks differ across tasks.

3.3.1 Contrastive Learning. Contrastive learning task aims to align the feature spaces of different modalities by encouraging similar representation for positive pairs and contrasting them with negative pairs. It helps to learn better modality-specific representation before fusion. As a result, modality interaction is restricted during attention calculation. We apply a unimodal attention mask, as shown in Figure 2. During contrastive learning, the forward pass bypasses the shared expert and Fusion Transformer.

The [CLS] tokens $\pmb { g } _ { c l s } ^ { e }$ and ${ m _ { c l s } ^ { e } }$ from the EEG expert and EYE expert are used to compute the InfoNCE loss [22]. The similarity function is computed as sim $( G , M ) = f _ { c } ^ { g } ( { \pmb g } _ { c l s } ^ { e } ) ^ { T } f _ { c } ^ { m } ( { \pmb m } _ { c l s } ^ { e } )$ , where $f _ { c } ^ { \dot { g } }$ and $f _ { c } ^ { m }$ are linear projections that map the [CLS] tokens to normalized representation (contrastive head in Figure 2). The contrastive loss is:

$$
\mathcal { L } _ { c o n } = - \frac { 1 } { 2 } \log \frac { e ^ { \sin ( G , M ) / \tau } } { \sum _ { i = 1 } ^ { N } e ^ { \sin ( G , M _ { i } ) / \tau } } - \frac { 1 } { 2 } \log \frac { e ^ { \sin ( G , M ) / \tau } } { \sum _ { i = 1 } ^ { N } e ^ { \sin ( G _ { i } , M ) / \tau } } ,\tag{6}
$$

where N is the total batch size and τ is a learnable temperature parameter. Distributed training is used to expand in-batch negatives.

3.3.2 Modality Matching. Modality matching task is a classification task that determines whether two modalities are matched or unmatched by allowing full modality interaction. Consequently, no attention mask is applied, and the forward pass includes the shared expert and fusion Transformer. Similar to [12-14], we employ a hard negative mining strategy, where negative pairs with higher contrastive similarity are more likely to be selected and labeled as 0, while positive pairs are labeled as 1.

The predicted probability is computed using the [CLS] tokens. The [CLS] tokens $r _ { c l s } ^ { g }$ and $r _ { c l s } ^ { m }$ from the two modalities are fused to form $r _ { c l s }$ using the same fusion method as in modality-specific gate. The predicted probabilities for the two classes are given by $\pmb { \mathrm { p } } = f _ { m } ( r _ { c l s } )$ , where $f _ { m }$ is a linear projection followed by softmax (matching head in Figure 2). The objective function of modality matching task is the cross-entropy $F _ { c s }$ between p and the groundtruth label y:

$$
\mathcal { L } _ { m a t } = F _ { c s } ( \pmb { p } , \pmb { y } ) .\tag{7}
$$

3.3.3 Modality Generation. Modality generation task aims to causally generate tokens of one modality, given another modality as the condition. It focuses not only on modeling cross-modal interactions but also on preserving intra-modal temporal causal relationships. Taking EEG generation as an example, as shown in Figure 2, all EEG tokens can access the eye movement tokens, while EEG tokens are constrained by a causal mask. The forward pass includes both the shared expert and fusion Transformer, enabling the EEG modality to fully leverage information from the eye movement modality.

We denote the generated value of the $i _ { t h }$ EEG token as $\hat { \pmb g } _ { i }$ It is generated from the $( i - 1 ) _ { t h }$ token: $\hat { \pmb { g } } _ { i } = f _ { g } ^ { g } ( \pmb { r } _ { i - 1 } ^ { g } ) , i \in \{ 1 , \cdot \cdot \cdot , s \}$ and $r _ { 0 } ^ { g } = r _ { c l s } ^ { g }$ , where $f _ { g } ^ { g }$ is the linear projection corresponding to EEG (generation head in Figure 2). It is used to map the token back to the input feature dimension. The objective function of the modality generation task is the mean squared error (MSE) loss:

$$
\begin{array} { r c l } { \mathcal { L } _ { g e n } ^ { g } } & { = } & { \displaystyle \frac { 1 } { s } \sum _ { i = 1 } ^ { s } | | \hat { \pmb { g } } _ { i } - \pmb { g } _ { i } | | ^ { 2 } , } \end{array}\tag{8}
$$

$$
\begin{array} { r c l } { \mathcal { L } _ { g e n } ^ { m } } & { = } & { \displaystyle \frac { 1 } { s } \sum _ { i = 1 } ^ { s } \| \hat { \pmb { m } } _ { i } - \pmb { m } _ { i } \| ^ { 2 } , } \end{array}\tag{9}
$$

$$
\begin{array} { r c l } { { \mathcal { L } } _ { g e n } } & { = } & { \displaystyle \frac { 1 } { 2 } { \mathcal L } _ { g e n } ^ { g } + \frac { 1 } { 2 } { \mathcal L } _ { g e n } ^ { m } . } \end{array}\tag{10}
$$

Finally, the full pre-training loss of UMAP is:

$$
\mathcal { L } = \mathcal { L } _ { c o n } + \mathcal { L } _ { m a t } + \mathcal { L } _ { g e n } .\tag{11}
$$

## 3.4 Fine-tuning with Missing or Complete Modalities

After multimodal and multi-task pre-training, UMAP can flexibly adapt to both missing and complete modalities based on the specific needs of different subjects. Figure 3 illustrates the fine-tuning process when eye movement is absent. By simply deactivating eye movement-specific modules, such as the EYE expert and EYE gate, UMAP can be fine-tuned using the available EEG features. The EEG [CLS] token is passed through a fully-connected layer to compute the predicted probability (CLS head in Figure 3). When both modalities are available, the [CLS] tokens from both modalities are fused using the same method as in the modality-specific gate, followed by a fully-connected layer to compute the final predicted probability.

![](images/41f521b20dd49b38570e7b264647ffa6fd6b30ea2757b732998da95577b3bad8.jpg)  
Figure 3: The fine-tuning stage of UMAP in the absence of eye movement. UMAP can be fine-tuned using the available EEG features by simply deactivating eye movement-specific modules, such as the EYE expert and EYE gate.

## 4 Experiments

## 4.1 Datasets and Features

We select three widely acknowledged multimodal emotion datasets: SEED-IV [38], SEED-V [17], and SEED-VII [8]. These datasets include EEG and eye movement signals, with each subject participating in three experimental sessions (four sessions for SEED-VII). All datasets employed the ESI NeuroScan 62-channel EEG acquisition system for EEG data collection.

SEED-IV: This dataset includes four emotional states: happiness, sadness, fear, and neutrality. It contains data from 15 participants, comprising 7 males and 8 females, with ages ranging from 20 to 24 years. Each participant participated in three experimental sessions, where they watched 24 video clips, with 8 clips corresponding to each emotional state. Eye movement data were collected using the SMI ETG eye-tracking glasses.

SEED-V: This dataset includes five emotional states: happiness, sadness, fear, disgust, and neutrality. It contains data from 16 participants, comprising 6 males and 10 females. Each participant was required to complete the Eysenck Personality Questionnaire (EPQ)

to select individuals with extroverted personalities, high emotional susceptibility, and stability. Each participant took part in three experimental sessions, where they watched 15 video clips in each session, with 3 clips corresponding to each emotional state. Eye movement data were collected using the SMI ETG eye-tracking glasses.

SEED-VII: This dataset includes seven emotional states: happiness, sadness, fear, disgust, surprise, anger, and neutrality. It contains data from 20 participants, comprising 10 males and 10 females, with ages ranging from 19 to 26 years, with an average age of 22.5 years. The EPQ questionnaire was applied. Each participant took part in four experimental sessions, where they watched 20 video clips in each session. To avoid participant fatigue due to the large number of emotional states to be induced, only 5 emotions were triggered per session. Eye movement data were collected using the Tobii eye tracker.

We conduct experiments under the subject-dependent condition and follow the cross-validation method provided in [8, 17]. SEED-IV and SEED-V use three-fold cross-validation, while SEED-VII uses four-fold cross-validation. For each time, one fold is used as the test set, and the remaining folds are used as the training set. The training sets from all participants are concatenated to form the pretraining dataset. The final result for each participant is the average performance across the three (or four) folds. The specific folding procedure is as follows: for each subject, the video clips viewed during each session are divided into three parts in chronological order (four parts for SEED-VII), and the corresponding parts from the three (or four) experimental sessions are concatenated to form one fold.

Since the number of videos for each emotion is equal across the three datasets, the labels are balanced. We use accuracy and Weighted F1 score as evaluation metrics and report the average and standard deviation across all participants. Accuracy is used as the monitoring metric.

For EEG, we extract differential entropy (DE) features, which perform excellently in EEG-based emotion recognition tasks [3]. The DE features consist of 310 dimensions. For eye movement, we extract features including pupil diameter and dispersion, blink, fixation, and saccades. SEED-IV contains 31 features, while SEED-V and SEED-VII contain 33 features.

## 4.2 Implementation Details

The AdamW optimizer is utilized for both pre-training and finetuning. The pre-training is performed on 8 NVIDIA 3090 GPUs. We set the learning rate to 0.0001 with a cosine decay learning rate schedule, weight decay to 0.05, batch size to 2048. The number of epochs is 200. For fine-tuning, we use a single NVIDIA 3090 GPU, with learning rate tuned from the 0.001 to 0.0005 and weight decay from 0.0001 to 0.1. The batch size is 256, and the number of epochs is 100. All dropout rates are set to 0.1. All methods are trained with the same settings for a fair comparison. The $N _ { e }$ and $N _ { f }$ in Figure 2 are set to 3 and 1, respectively. The self-attention layer has 4 heads, and the feature dimension d is 64. Following [8] the number of sequences s is set to 5. For other methods that also use Transformer structures, the total number of layers, heads, and hidden dimensions are set to 4, 4, and 64, respectively, to match the configuration of UMAP.

## 4.3 Methods for comparison

We selected two categories of methods for comparison. The first category includes traditional multimodal methods, while the second category consists of multimodal methods specifically designed to handle modality missing scenarios. The traditional methods include:

• ETF [29]: It fuses the outputs of EEG and eye movement Transformer encoders using an attention fusion layer.

• SDT [21]: It incorporates both intra-modality and intermodality Transformer for each modality and designs a gating mechanism to fuse the outputs.

• VigilanceNet [2]: It utilizes CNN to extract EOG features and Transformer to extract EEG features, followed by a crossattention model for feature fusion.

• TSSL [31]: It uses CNN to extract features for each modality and concatenates all the features along the sequence dimension before feeding them into the Transformer.

The multimodal methods specifically designed to handle modality missing scenarios include:

• IMDer [30]: It utilizes diffusion models to generate missing modality features.

• MMIN [36]: It reconstructs joint representations using cascaded residual autoencoders.

• MoMKE [32]: It trains modality experts independently for each modality and fuses the outputs of all experts using a soft routing mechanism.

• CLIP [23]: It pre-trains modality experts using contrastive learning. Note that under conditions of complete modalities, the output of each expert modality is fused using the same method as ETF.

• MLA [35]: It introduces shared heads to enhance modality experts for capturing cross-modal information.

• MAET [8]: It constructs multi-view representations of modalities and uses FFN layers as modality experts.

## 4.4 Results Analysis and Comparison

Table 1 presents the performance of different methods under both modality missing and modality complete test conditions, where the second row indicates the accessible modalities during testing (e.g., EEG means only the EEG modality is available, with the eye movement modality missing). Bold indicates the best overall performance. Underlined represents the best for methods handling missing modalities, and dashed line denotes the best for traditional multimodal approaches.

In the first section (Traditional Multimodal Methods) of Table 1, when all modality data are available, SDT and ETF achieve the best performance. For modality missing scenarios, since these methods were not optimized for such situations, zero-padding is used to replace the missing modality during testing. As a result, the performance of these traditional methods significantly declines, and their standard deviation increases accordingly.

In the second section (Models Specifically Designed for Modality Missing Scenarios) of Table 1, no model consistently achieves the best performance in both modality complete and modality incomplete settings. For instance, on the SEED-V dataset, IMDer achieves the highest performance when all modality data are available, with UMAP surpassing it by 0.51%. However, when modalities are missing, IMDer's performance drops sharply. When only EEG data is available, UMAP outperforms it by 12.33%, and when only eye movement data is available, UMAP outperforms it by 17.13%. MMIN performs best when only EEG data is available, with UMAP surpassing it by 1.09%, but MMIN performs poorly when only eye movement data is available, with UMAP outperforming it by 3.83% CLIP performs best when only eye movement data is available, with UMAP surpassing it by 2.99%, but when all modalities are present, CLIP's handling of joint representations is insufficient, leading to poorer classification performance, with UMAP outperforming it by 5.02%.

IMDer relies on a diffusion mechanism to reconstruct the missing modality, while MMIN uses a cascaded residual autoencoder for joint representation reconstruction. When all modality data are available, these modules are redundant. In contrast, UMAP outperforms these models, achieving optimal results in both modality complete and incomplete settings without introducing unnecessary components, thus maintaining relatively low computational cost.

## 4.5 Ablation Study

4.5.1 Training from Scratch. To demonstrate the effectiveness of pre-training, we compare the performance of the pre-trained model and the model trained from scratch on the same tasks. Results are shown in Figure 4. The performance of the model trained from scratch shows a significant decline, regardless of whether the modalities are complete or missing.

![](images/df1341b6ce1951dd2c7bf8acd7210aeb1d88f87793fbddf7812e960174a7ab22.jpg)  
Figure 4: Comparison with the model without pre-training. Light colors represent no pre-training, while dark colors indicate pre-training.

4.5.2 Pre-training Tasks. As shown in Table 2, to assess the effectiveness of each pre-training task, we perform ablation experiments by removing one task at a time. Bold and underlined indicates the best and the second-best performance, respectively.

Table 1: Performance(%) of different methods under missing-modality and full-modality testing conditions.
<table><tr><td></td><td colspan="4">SEED-IV</td><td colspan="3">SEED-V</td><td colspan="3">SEED-VII</td></tr><tr><td></td><td>Available</td><td>EEG, EYE</td><td>EEG</td><td>EYE</td><td>EEG, EYE</td><td>EEG</td><td>EYE</td><td>EEG, EYE</td><td>EEG</td><td>EYE</td></tr><tr><td></td><td>ETF SDT</td><td>85.64/7.10</td><td>57.17/19.18</td><td>51.33/18.00</td><td>83.75/6.32</td><td>58.70/12.79</td><td>45.67/13.99</td><td>70.13/6.34</td><td>48.41/12.37</td><td>36.96/11.32</td></tr><tr><td></td><td></td><td>85.79/6.78</td><td>60.66/13.79</td><td>52.46/8.79</td><td>83.69/9.04</td><td>61.66/11.46</td><td>51.33/18.00</td><td>72.52/8.50</td><td>46.63/10.28</td><td>34.51/6.52</td></tr><tr><td>AÁccy</td><td>VigilanceNet</td><td>84.12/6.97</td><td>39.49/10.21</td><td>50.83/10.74</td><td>80.29/6.74</td><td>49.58/12.85</td><td>34.39/6.57</td><td>63.75/6.94</td><td>41.30/6.92</td><td>22.52/4.89</td></tr><tr><td></td><td>TSSL</td><td>85.55/6.79</td><td>59.50/14.67</td><td>53.21/10.27</td><td>83.25/9.75</td><td>59.72/14.54</td><td>41.09/7.64</td><td>71.68/7.32</td><td>49.14/9.68</td><td>26.42/5.51</td></tr><tr><td></td><td>IMDer</td><td>87.21/6.56</td><td>72.71/9.77</td><td>68.95/10.05</td><td>84.82/8.50</td><td>70.60/8.82</td><td>58.82/8.27</td><td>71.81/9.06</td><td>55.57/10.66</td><td>50.05/7.56</td></tr><tr><td></td><td>MMIN</td><td>85.99/7.12</td><td>83.38/9.46</td><td>77.14/7.72</td><td>83.78/8.63</td><td>81.84/7.71</td><td>72.12/6.60</td><td>70.96/9.07</td><td>65.88/8.79</td><td>56.44/6.96</td></tr><tr><td></td><td>MoMKE</td><td>87.00/6.33</td><td>63.30/14.30</td><td>61.29/12.69</td><td>84.04/9.02</td><td>58.60/14.60</td><td>45.75/5.95</td><td>73.00/9.07</td><td>50.72/10.30</td><td>39.47/8.55</td></tr><tr><td></td><td>CLIP</td><td>83.33/7.23</td><td>81.60/8.45</td><td>79.82/7.48</td><td>80.31/6.71</td><td>78.71/8.08</td><td>72.96/6.18</td><td>69.54/6.87</td><td>65.61/9.17</td><td>60.24/7.46</td></tr><tr><td></td><td>MLA</td><td>86.51/5.83</td><td>71.17/13.53</td><td>65.14/8.14</td><td>84.35/6.10</td><td>67.79/15.10</td><td>53.99/10.24</td><td>69.92/7.65</td><td>54.17/9.86</td><td>47.10/8.05</td></tr><tr><td></td><td>MAET</td><td>85.94/7.77</td><td>71.41/10.62</td><td>72.16/9.11</td><td>84.19/8.33</td><td>71.00/8.65</td><td>64.24/8.75</td><td>71.28/7.74</td><td>58.11/8.78</td><td>50.31/7.14</td></tr><tr><td></td><td>UMAP</td><td>87.66/6.42</td><td>83.97/7.88</td><td>79.96/7.82</td><td>85.33/6.33</td><td>82.93/7.65</td><td>75.95/7.19</td><td>74.05/7.03</td><td>67.09/8.04</td><td>61.94/7.90</td></tr><tr><td></td><td>ETF</td><td>85.28/7.45</td><td>50.34/23.05</td><td>43.32/22.19</td><td>82.76/6.75</td><td>52.68/14.87</td><td>35.11/15.40</td><td>68.07/7.14</td><td>42.28/14.55</td><td>28.78/13.05</td></tr><tr><td></td><td>SDT VigilanceNet</td><td>85.55/6.89</td><td>57.02/15.31</td><td>47.82/10.19</td><td>82.79/9.44</td><td>50.34/23.05</td><td>43.32/22.19</td><td>70.77/8.97</td><td>42.46/10.93</td><td>26.63/6.89</td></tr><tr><td></td><td>TSSL</td><td>83.78/7.29</td><td>29.10/12.66</td><td>44.02/13.11</td><td>78.70/7.46</td><td>41.79/15.73</td><td>24.10/6.91</td><td>61.52/7.54</td><td>35.28/8.14</td><td>12.19/5.68</td></tr><tr><td></td><td></td><td>84.97/7.43</td><td>53.91/17.23</td><td>47.13/11.89</td><td>82.52/10.97</td><td>55.36/16.68</td><td>32.36/8.74</td><td>69.95/7.78</td><td>44.65/10.06</td><td>17.39/5.92</td></tr><tr><td>F  re</td><td>IMDer</td><td>87.02/6.65</td><td>72.13/10.06</td><td>67.38/10.90</td><td>84.52/8.63</td><td>69.61/9.36</td><td>56.86/8.53</td><td>70.04/9.78</td><td>53.26/11.49</td><td>47.31/7.70</td></tr><tr><td></td><td>MMIN</td><td>85.65/7.58</td><td>83.10/9.68</td><td>75.89/8.21</td><td>83.05/9.48</td><td>80.90/8.52</td><td>69.63/7.65</td><td>69.11/9.71</td><td>63.47/9.61</td><td>53.49/7.72</td></tr><tr><td></td><td>MoMKE</td><td>86.88/6.43</td><td>61.57/15.31</td><td>58.83/14.06</td><td>83.64/10.28</td><td>56.07/16.00</td><td>42.31/6.86</td><td>71.30/9.87</td><td>48.06/10.94</td><td>34.72/8.60</td></tr><tr><td></td><td>CLIP</td><td>82.64/7.86</td><td>81.45/8.43</td><td>79.02/7.92</td><td>79.53/6.58</td><td>77.59/8.51</td><td>70.83/7.11</td><td>67.54/7.79</td><td>63.68/9.29</td><td>57.88/8.20</td></tr><tr><td></td><td>MLA</td><td>86.32/6.02</td><td>70.01/14.46</td><td>63.50/8.85</td><td>83.06/6.43</td><td>65.89/16.72</td><td>50.48/10.45</td><td>68.29/8.28</td><td>51.87/10.16</td><td>44.14/8.23</td></tr><tr><td></td><td>MAET</td><td>85.50/8.19</td><td>70.99/10.94</td><td>71.15/9.57</td><td>83.80/8.90</td><td>70.30/8.98</td><td>62.10/8.63</td><td>69.16/8.35</td><td>54.98/9.45</td><td>47.10/7.84</td></tr><tr><td></td><td>UMAP</td><td>87.45/6.58</td><td>83.78/7.83</td><td>79.26/8.01</td><td>85.00/6.60</td><td>82.44/8.16</td><td>74.57/7.80</td><td>72.37/7.76</td><td>65.06/8.52</td><td>59.50/8.47</td></tr></table>

Table 2: Ablation study of pre-training tasks under missing-modality and full-modality testing conditions.
<table><tr><td></td><td colspan="4">SEED-IV</td><td colspan="3">SEED-V</td><td colspan="3">SEED-VII</td></tr><tr><td></td><td>Available</td><td>EEG, EYE</td><td>EEG</td><td>EYE</td><td>EEG, EYE</td><td>EEG</td><td>EYE</td><td>EEG, EYE</td><td>EEG</td><td>EYE</td></tr><tr><td rowspan="4">AÁuacy</td><td>UMAP</td><td>87.66/6.42</td><td>83.97/7.88</td><td>79.96/7.82</td><td>85.33/6.33</td><td>82.93/7.65</td><td>75.95/7.19</td><td>74.05/7.03</td><td>67.09/8.04</td><td>61.94/7.90</td></tr><tr><td> $\mathbf { w } / 0 \mathcal { L } _ { c o n }$ </td><td>87.19/5.98</td><td>83.80/7.74</td><td>80.05/7.47</td><td>83.46/7.27</td><td>82.89/6.95</td><td>76.01/7.46</td><td>72.70/7.32</td><td>67.03/8.08</td><td>61.80/7.80</td></tr><tr><td> $\mathbf { w } / 0 \mathcal { L } _ { m a t }$ </td><td>86.86/6.88</td><td>83.95/7.35</td><td>79.50/7.36</td><td>84.27/6.56</td><td>82.34/7.49</td><td>75.92/7.69</td><td>73.79/6.39</td><td>66.48/7.95</td><td>61.53/7.96</td></tr><tr><td>w/o  $\mathcal { L } _ { g e n }$ </td><td>84.34/7.73</td><td>80.93/7.93</td><td>79.87/7.41</td><td>80.14/7.12</td><td>79.73/9.39</td><td>75.13/6.84</td><td>68.29/6.12</td><td>65.68/7.97</td><td>59.47/6.31</td></tr><tr><td rowspan="4">F  re</td><td>UMAP</td><td>87.45/6.58</td><td>83.78/7.83</td><td>79.26/8.01</td><td>85.00/6.60</td><td>82.44/8.16</td><td>74.57/7.80</td><td>72.37/7.76</td><td>65.06/8.52</td><td>59.50/8.47</td></tr><tr><td> $\mathbf { w } / 0 \ \mathcal { L } _ { c o n }$ </td><td>87.08/6.02</td><td>83.59/7.82</td><td>79.33/7.65</td><td>82.48/8.07</td><td>82.25/7.76</td><td>74.44/8.18</td><td>70.89/7.86</td><td>64.88/8.36</td><td>59.33/8.04</td></tr><tr><td> $\mathbf { w } / 0 \mathcal { L } _ { m a t }$ </td><td>86.44/7.27</td><td>83.70/7.46</td><td>79.09/7.93</td><td>84.20/6.96</td><td>81.52/8.03</td><td>74.41/8.43</td><td>72.01/6.68</td><td>64.53/8.41</td><td>59.13/8.46</td></tr><tr><td>w/o  $\mathcal { L } _ { g e n }$ </td><td>83.75/8.46</td><td>80.58/8.10</td><td>78.66/7.98</td><td>79.82/7.63</td><td>78.64/10.12</td><td>73.88/8.16</td><td>66.24/6.72</td><td>62.96/8.88</td><td>56.89/6.61</td></tr></table>

Under modality complete conditions, the model performs optimally when both $\mathcal { L } _ { c o n }$ and $\mathcal { L } _ { m a t }$ are used simultaneously. For the SEED-V and SEED-VII datasets, pretraining with $\mathcal { L } _ { c o n }$ outperforms $\mathcal { L } _ { m a t } .$ Specifically, removing $\mathcal { L } _ { c o n }$ results in performance drops of 1.87% and 1.35% on SEED-V and SEED-VII, respectively, while removing $\mathcal { L } _ { m a t }$ leads to performance drops of 1.06% and 0.25%. Conversely, Lmat performs better on the SEED-IV dataset, with its removal causing a performance drop of 0.8%, while removing $\mathcal { L } _ { c o n }$ leads to a smaller performance drop of 0.47%.

Table 3: Ablation study of model structures under missing-modality and full-modality testing conditions.
<table><tr><td></td><td></td><td colspan="3">SEED-IV</td><td colspan="3">SEED-V</td><td colspan="3">SEED-VII</td></tr><tr><td></td><td>Available</td><td>EEG, EYE</td><td>EEG</td><td>EYE</td><td>EEG, EYE</td><td>EEG</td><td>EYE</td><td>EEG, EYE</td><td>EEG</td><td>EYE</td></tr><tr><td>AÁacy</td><td>UMAP</td><td>87.66/6.42</td><td>83.97/7.88</td><td>79.96/7.82</td><td>85.33/6.33</td><td>82.93/7.65</td><td>75.95/7.19</td><td>74.05/7.03</td><td>67.09/8.04</td><td>61.94/7.90</td></tr><tr><td></td><td>w/o Shared Expert</td><td>86.47/6.89</td><td>83.27/6.92</td><td>79.61/7.56</td><td>84.23/8.46</td><td>81.68/6.81</td><td>73.92/6.52</td><td>73.35/6.67</td><td>66.29/7.94</td><td>61.02/8.00</td></tr><tr><td></td><td>w/o Fusion Transformer</td><td>85.35/7.23</td><td>83.00/8.03</td><td>78.83/7.76</td><td>85.01/7.36</td><td>82.73/7.40</td><td>75.59/7.46</td><td>73.85/7.73</td><td>66.92/8.61</td><td>61.59/7.79</td></tr><tr><td></td><td>UMAP</td><td>87.45/6.58</td><td>83.78/7.83</td><td>79.26/8.01</td><td>85.00/6.60</td><td>82.44/8.16</td><td>74.57/7.80</td><td>72.37/7.76</td><td>65.06/8.52</td><td>59.50/8.47</td></tr><tr><td>F  re</td><td>w/o Shared Expert</td><td>86.14/7.12</td><td>83.16/7.04</td><td>78.87/8.14</td><td>83.31/9.18</td><td>81.33/7.01</td><td>71.79/8.13</td><td>71.90/7.11</td><td>64.55/8.37</td><td>58.57/8.64</td></tr><tr><td></td><td>w/o Fusion Transformer</td><td>85.11/7.48</td><td>82.93/7.99</td><td>77.58/8.19</td><td>84.57/7.68</td><td>82.29/7.75</td><td>73.81/8.33</td><td>71.92/8.34</td><td>64.98/9.10</td><td>59.16/8.34</td></tr></table>

Although both contrastive learning and modality matching tasks measure the similarity between modalities, their emphasis differs. Contrastive learning aims to learn better unimodal representations before calculating modality similarity. Its focus is primarily on modality experts, aiming to map the representations of two modalities to a similar space. In contrast, the modality matching task ensures adequate information exchange between modalities to determine whether sample pairs match. This task emphasizes the role of shared experts and fusion components. Therefore, these differing emphases collectively enhance multimodal performance.

When modality is missing, performance with either $\mathcal { L } _ { c o n }$ or $\mathcal { L } _ { m a t }$ alone is nearly identical to using both tasks together. Meanwhile, on the SEED-IV and SEED-V datasets, removing $\mathcal { L } _ { c o n }$ even leads to performance improvements of 0.09% and 0.06% for the eye movement data, respectively. This suggests that both tasks rely on communication between modalities. The absence of one modality eliminates the need for inter-modal communication, consequently leading to comparable task performance.

Regardless of modality missing or complete, the modality generation task always performs the best, with its removal leading to the largest performance drop. For instance, on the SEED-V dataset, removing $\mathcal { L } _ { g e n }$ causes performance drops of 5.19%, 3.2%, and 0.82% under the modality complete, EEG-only, and eye-movement-only conditions, respectively. Unlike the other two tasks, the modality generation task not only emphasizes information exchange between modalities (e.g., predicting EEG from eye movement data), but also strengthens the temporal causal relationships within each modality through the causal prediction task. This may explain why the modality generation task plays a crucial role.

4.5.3 Model Structure. To validate the effectiveness of the model structure, we conduct ablation experiments on two fusion modules—shared expert and fusion Transformer. The results are shown in Table 3. Removing either shared expert or fusion Transformer leads to varying degrees of performance degradation. Specifically, for the SEED-IV dataset, the fusion Transformer layer proves more effective, with a more significant performance drop when removed. In contrast, for the SEED-V and SEED-VII datasets, the shared expert module plays a more crucial role, and removing the fusion Transformer causes a relatively smaller performance change. These results confirm the effectiveness of the fusion modules.

## 5 Conclusion

This paper introduces UMAP, a multimodal emotion recognition method based on EEG and eye movement signals, specifically designed for modality missing scenarios. UMAP overcomes the limitations of previous models by combining modality-specific and joint information without introducing additional generative modules, and its performance is enhanced through self-supervised pretraining. UMAP consists of two stages. After multi-task pre-training on complete, unlabeled multimodal data from all subjects, UMAP can be fine-tuned for each subject to meet their specific modality requirements. In the case of modality missing, fine-tuning can be performed by simply deactivating the corresponding expert model.

Experiments conducted on three datasets show that UMAP achieves SOTA performance under both modality complete and incomplete conditions. For example, on the SEED-V dataset, under modality complete conditions, UMAP outperforms the suboptimal model (IMDer) by 0.51%. When only EEG data is available, UMAP outperforms the suboptimal model (MMIN) by 1.09% and when only eye movement data is available, UMAP outperforms the suboptimal model (CLIP) by 2.99%. Meanwhile, ablation experiments confirm the important roles of the three pre-training losses. Among them, the modality generation pre-training task yields the best performance across all conditions.

Since contrastive learning and modality matching tasks in UMAP focus solely on pairwise relationships, UMAP is currently limited to two modalities. A key direction for future research is to explore how to effectively extend the number of modalities.

## Acknowledgments

This work was supported in part by grants from STI 2030-Major Projects+2022ZD0208500, National Natural Science Foundation of China (Grant No. 62376158), Shanghai Municipal Science and Technology Major Project (Grant No. 2021SHZD ZX), Medical-Engineering Interdisciplinary Research Foundation of Shanghai Jiao Tong University "Jiao Tong Star" Program (YG2023ZD25, YG2024ZD-25 and YG2024QNA03), Shanghai Pujiang Program (Grant No. 22PJ1- 408600), Shanghai Pilot Program for Basic Research - Shanghai Jiao Tong University (No. 21TQ1400203), Shanghai Jiao Tong University 2030 Initiative, and Shanghai Jiao Tong University SCS-Shanghai EmoRays Technology Co., Ltd Joint Laboratory of Affective Brain-Computer Interfaces.

## References

[1] Weidong Chen, Xiaofen Xing, Peihao Chen, and Xiangmin Xu. 2024. Vesper: a compact and effective pretrained model for speech emotion recognition. IEEE Transactions on Affective Computing (2024).

[2] Xinyu Cheng, Wei Wei, Changde Du, Shuang Qiu, Sanli Tian, Xiaojun Ma, and Huiguang He. 2022. Vigilancenet: decouple intra-and inter-modality learning for multimodal vigilance estimation in RSVP-based BCI. In Proceedings of the 30th ACM International Conference on Multimedia. 209–217.

[3] Ruo-Nan Duan, Jia-Yi Zhu, and Bao-Liang Lu. 2013. Differential entropy feature for EEG-based emotion classification. In International IEEE/EMBS Conference on Neural Engineering. IEEE, 81–84.

[4] AV Geetha, T Mala, D Priyanka, and E Uma. 2024. Multimodal Emotion Recognition with deep learning: advancements, challenges, and future directions. Information Fusion 105 (2024), 102218.

[5] Xinrong Gong, CL Philip Chen, Bin Hu, and Tong Zhang. 2024. CiABL: Completeness-induced Adaptative Broad Learning for Cross-Subject Emotion Recognition with EEG and Eye Movement Signals. IEEE Transactions on Affective Computing (2024).

[6] Ziyu Jia, Youfang Lin, Jing Wang, Zhiyang Feng, Xiangheng Xie, and Caijie Chen. 2021. HetEmotionNet: two-stream heterogeneous graph recurrent neural network for multi-modal emotion recognition. In Proceedings of the 29th ACM International Conference on Multimedia. 1047-1056.

[7] Wei-Bang Jiang, Ziyi Li, Wei-Long Zheng, and Bao-Liang Lu. 2024. Functional emotion transformer for EEG-assisted cross-modal emotion recognition. In IEEE International Conference on Acoustics, Speech and Signal Processing. IEEE, 1841– 1845.

[8] Wei-Bang Jiang, Xuan-Hao Liu, Wei-Long Zheng, and Bao-Liang Lu. 2024. SEED-VII: a Multimodal Dataset of Six Basic Emotions with Continuous Labels for Emotion Recognition. IEEE Transactions on Affective Computing (2024).

[9] Smith K Khare, Victoria Blanes-Vidal, Esmaeil S Nadimi, and U Rajendra Acharya. 2024. Emotion recognition and artificial intelligence: a systematic review (2014– 2023) and research recommendations. Information Fusion 102 (2024), 102019.

[10] Rayan Krishnan, Pranav Rajpurkar, and Eric J. Topol. 2022. Self-supervised learning in medicine and healthcare. Nature Biomedical Engineering 6 (2022), 1346 - 1352.

[11] Yu-Ting Lan, Wei Liu, and Bao-Liang Lu. 2020. Multimodal Emotion Recognition Using Deep Generalized Canonical Correlation Analysis with an Attention Mechanism. 2020 International Joint Conference on Neural Networks (2020), 1-6.

[12] Junnan Li, Dongxu Li, Silvio Savarese, and Steven Hoi. 2023. BLIP-2: bootstrapping language-image pre-training with frozen image encoders and large language models. In International Conference on Machine Learning. PMLR, 19730-19742.

[13] Junnan Li, Dongxu Li, Caiming Xiong, and Steven Hoi. 2022. BLIP: bootstrapping language-image pre-training for unified vision-language understanding and generation. In International Conference on Machine Learning. PMLR, 12888-12900.

[14] Junnan Li, Ramprasaath Selvaraju, Akhilesh Gotmare, Shafiq Joty, Caiming Xiong, and Steven Chu Hong Hoi. 2021. Align before fuse: vision and language representation learning with momentum distillation. In Advances in Neural Information Processing Systems, Vol. 34. 9694–9705.

[15] Rui Li, Yiting Wang, Wei-Long Zheng, and Bao-Liang Lu. 2022. A multi-view spectral-spatial-temporal masked autoencoder for decoding emotions with selfsupervised learning. In Proceedings of the 30th ACM International Conference on Multimedia. 6-14.

[16] Ronghao Lin and Haifeng Hu. 2024. Adapt and explore: multimodal mixup for representation learning. Information Fusion 105 (2024), 102216.

[17] Wei Liu, Jielin Qiu, Wei-Long Zheng, and Bao-Liang Lu. 2021. Comparing Recognition Performance and Robustness of Multimodal Deep Learning Models for Multimodal Emotion Recognition. IEEE Transactions on Cognitive and Developmental Systems 14 (2021), 715–729.

[18] Wei Liu, Wei-Long Zheng, Ziyi Li, Si-Yuan Wu, Lu Gan, and Bao-Liang Lu. 2022. Identifying similarities and differences in emotion recognition with EEG and eye movements among Chinese, German, and French People. Journal of Neural Engineering 19, 2 (2022), 026012.

[19] W. Liu, Wei-Long Zheng, and Bao-Liang Lu. 2016. Emotion Recognition Using Multimodal Deep Learning. In International Conference on Neural Information

Processing.

[20] Yifei Lu, Wei-Long Zheng, Binbin Li, and Bao-Liang Lu. 2015. Combining Eye Movements and EEG to Enhance Emotion Recognition.. In International Joint Conference on Artificial Intelligence, Vol. 15. Buenos Aires, 1170–1176.

[21] Hui Ma, Jian Wang, Hongfei Lin, Bo Zhang, Yijia Zhang, and Bo Xu. 2023. A transformer-based model with self-distillation for multimodal emotion recognition in conversations. IEEE Transactions on Multimedia (2023).

[22] Aaron van den Oord, Yazhe Li, and Oriol Vinyals. 2018. Representation learning with contrastive predictive coding. ArXiv Preprint ArXiv:1807.03748 (2018).

[23] Alec Radford, Jong Wook Kim, Chris Hallacy, Aditya Ramesh, Gabriel Goh, Sandhini Agarwal, Girish Sastry, Amanda Askell, Pamela Mishkin, Jack Clark, et al. 2021. Learning transferable visual models from natural language supervision. In International Conference on Machine Learning. PMLR, 8748-8763.

[24] Jonathan Rottenberg. 2017. Emotions in depression: what do we really know. Annual Review of Clinical Psychology 13, 1 (2017), 241–263

[25] Fatma M Talaat, Zainab H Ali, Reham R Mostafa, and Nora El-Rashidy. 2024. Real-time facial emotion recognition model based on kernel autoencoder and convolutional neural network for autism children. Soft Computing (2024), 1–14.

[26] Ashish Vaswani, Noam M. Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N. Gomez, Lukasz Kaiser, and Illia Polosukhin. 2017. Attention is All you Need. In Annual Conference on Neural Information Processing Systems.

[27] Hu Wang, Yuanhong Chen, Congbo Ma, Jodie Avery, Louise Hull, and Gustavo Carneiro. 2023. Multi-modal learning with missing modality via shared-specific feature modelling. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. 15878-15887.

[28] Wenhui Wang, Hangbo Bao, Li Dong, Johan Bjorck, Zhiliang Peng, Qiang Liu, Kriti Aggarwal, Owais Khan Mohammed, Saksham Singhal, Subhojit Som, et al. 2023. Image as a foreign language: BEiT pretraining for vision and visionlanguage tasks. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. 19175–19186.

[29] Yiting Wang, Wei-Bang Jiang, Rui Li, and Bao-Liang Lu. 2021. Emotion Transformer Fusion: complementary Representation Properties of EEG and Eye Movements on Recognizing Anger and Surprise. 2021 IEEE International Conference on Bioinformatics and Biomedicine (2021), 1575–1578.

[30] Yuanzhi Wang, Yong Li, and Zhen Cui. 2023. Incomplete multimodality-diffused emotion recognition. Advances in Neural Information Processing Systems 36 (2023), 17117-17128.

[31] Yujin Wu, Mohamed Daoudi, and Ali Amad. 2023. Transformer-based selfsupervised multimodal representation learning for wearable emotion recognition. IEEE Transactions on Affective Computing 15, 1 (2023), 157–172.

[32] Wenxin Xu, Hexin Jiang, and Xuefeng Liang. 2024. Leveraging Knowledge of Modality Experts for Incomplete Multimodal Learning. In Proceedings of the 32nd ACM International Conference on Multimedia. 438-446.

[33] Xu Yan, Li-Ming Zhao, and Bao-Liang Lu. 2021. Simplifying multimodal emotion recognition with single eye movement modality. In Proceedings of the 29th ACM International Conference on Multimedia. 1057–1063

[34] Xue Yan, Wei-Long Zheng, W. Liu, and Bao-Liang Lu. 2017. Identifying Gender Differences in Multimodal Emotion Recognition Using Bimodal Deep AutoEncoder. In International Conference on Neural Information Processing

[35] Xiaohui Zhang, Jaehong Yoon, Mohit Bansal, and Huaxiu Yao. 2024. Multimodal representation learning by alternating unimodal adaptation. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition. 27456-27466.

[36] Jinming Zhao, Ruichen Li, and Qin Jin. 2021. Missing modality imagination network for emotion recognition with uncertain missing modalities. In Proceedings of the 59th Annual Meeting of the Association for Computational Linguistics and the 11th International Foint Conference on Natural Language Processing (Volume 1: Long Papers). 2608–2618.

[37] Wei-Long Zheng, B. Dong, and Bao-Liang Lu. 2014. Multimodal emotion recognition using EEG and eye tracking data. 2014 36th Annual International Conference of the IEEE Engineering in Medicine and Biology Society (2014), 5040–5043.

[38] Wei-Long Zheng, Wei Liu, Yifei Lu, Bao-Liang Lu, and Andrzej Cichocki. 2019. EmotionMeter: a Multimodal Framework for Recognizing Human Emotions. IEEE Transactions on Cybernetics 49 (2019), 1110–1122.