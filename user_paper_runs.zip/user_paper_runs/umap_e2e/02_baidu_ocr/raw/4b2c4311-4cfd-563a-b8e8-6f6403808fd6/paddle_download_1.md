<div style="text-align: center;">a) Pre-training</div>


<div style="text-align: center;">b) Fine-tuning</div>


<div style="text-align: center;"><img src="<temporary-url-redacted>" alt="Image" width="45%" /></div>


<div style="text-align: center;"><img src="<temporary-url-redacted>" alt="Image" width="44%" /></div>
