REVIEW

Open Access

# An overview of large AI models and their applications

![](images/cd6868665cdc7c618411859e0685b255d75b34fc340773e049cc449c85d33ac0.jpg)

Xiaoguang Tu $^{1}$ , Zhi He $^{1}$ , Yi Huang $^{2}$ , Zhi-Hao Zhang $^{3}$ , Ming Yang $^{1}$ and Jian Zhao $^{4,5*}$

## Abstract

In recent years, large-scale artificial intelligence (AI) models have become a focal point in technology, attracting widespread attention and acclaim. Notable examples include Google's BERT and OpenAI's GPT, which have scaled their parameter sizes to hundreds of billions or even tens of trillions. This growth has been accompanied by a significant increase in the amount of training data, significantly improving the capabilities and performance of these models. Unlike previous reviews, this paper provides a comprehensive discussion of the algorithmic principles of large-scale AI models and their industrial applications from multiple perspectives. We first outline the evolutionary history of these models, highlighting milestone algorithms while exploring their underlying principles and core technologies. We then evaluate the challenges and limitations of large-scale AI models, including computational resource requirements, model parameter inflation, data privacy concerns, and specific issues related to multi-modal AI models, such as reliance on text-image pairs, inconsistencies in understanding and generation capabilities, and the lack of true “multi-modality”. Various industrial applications of these models are also presented. Finally, we discuss future trends, predicting further expansion of model scale and the development of cross-modal fusion. This study provides valuable insights to inform and inspire future future research and practice.

Keywords: Artificial intelligence, Large AI models, Large language models, GPT

## 1 Introduction

Large artificial intelligence (AI) models refer to machine learning models with large-scale parameters and complex computational structures $[1]$ , typically built from deep neural networks $[2]$ and having billions or even trillions of parameters. The design intent of large AI models is to increase the expressive and predictive power of the model $[3]$ , enabling it to handle massive amounts of data and address more complex tasks. Through training on massive datasets, large AI models learn intricate patterns and data features and possess strong generalization capabilities $[4, 5]$ . They can automatically learn and discover new, higher-level data features and patterns from raw massive training data, a capability also known as “emergence”

[6–8]. Large AI models originated in natural language processing (NLP), with the introduction of the Transformer architecture in 2017 [9], which has since become a foundational model for various tasks, including NLP, computer vision (CV), and multi-modal applications. A year later, BERT [10] was introduced with a parameter count of 300 million. With this substantial number of parameters, researchers observed that it could effectively handle various NLP tasks simultaneously, which heightened interest in large AI models within the industry and prompted a growing number of AI researchers to explore the field of large-scale AI models.

At this point, a well-balanced review of “large AI models” can greatly assist researchers entering the field by saving them considerable effort in understanding relevant technological trends and challenges. In contrast to previous works, this paper elaborates on the development trends of large AI models in various directions, including large language models (LLMs), large vision models (LVMs), and large multi-modal models (LMMs). It provides a more detailed exposition of the key technologies underlying large AI models. The paper also provides a detailed description of the applications of large AI models in various industries and discusses their advantages, limitations, and future development trends.

In November 2022, with the simultaneous release of GPT-3.5 and ChatGPT by OpenAI, the latter was announced to be freely accessible to the general public [11]. This move caused ChatGPT to quickly gain global popularity, marking the first time that large AI models broke out of the confines of the “laboratory” and entered the daily lives of ordinary people. Notably, prior to this, OpenAI had already introduced the GPT-1, GPT-2 and GPT-3 language models [12]. In essence, ChatGPT is an upgraded version of GPT-3, known as GPT-3.5, with the addition of reinforcement learning from human feedback (RLHF) fine-tuning mechanisms [13]. This enhancement significantly improved the model’s performance. ChatGPT has demonstrated outstanding performance in various NLP domains, such as chatbots and information retrieval, attracting widespread global attention and heralding a new era in large AI model research.

In May 2022, Meta also released its LLM, OPT, with parameters matching those of GPT-3, reaching 175 billion [14]. They also open-sourced their code and model, along with disclosing the entire training process log, which has greatly promoted the practical application of large AI models. In April 2022, Google introduced its LLM, PaLM, with parameters reaching 540 billion [15]. Although China's large AI model research started later, its development has been rapid. In 2021, Baidu introduced the Chinese LLM ERNIE 3.0 with 10 billion parameters [16]. Subsequently, ERNIE 3.0 Titan, with a parameter scale of 260 billion, was proposed [17]. Meanwhile, Alibaba's DAMO Academy released M6 with an astonishing 100 trillion parameters [18], making it the world's largest AI pre-training model. In addition, Huawei proposed the Chinese LLM "PanGu- $\alpha$ ," with the number of parameters reaching 200 billion [19]. In March 2023, Huawei introduced the Chinese LLM "PanGu- $\Sigma$ ," with parameters reaching 1.085 trillion [20]. On May 14, 2024, OpenAI officially released the new LLM GPT-4o. It claimed that GPT-4o not only inherits the powerful intelligence of GPT-4, but also further enhances its text, image, and speech processing capabilities. Since then, various large AI models have continued to emerge.

This paper outlines the development history of large AI models and representative large AI model algorithms, introduces the basic architecture and core principles of large AI models, analyzes their characteristics, discusses their limitations, and explores future development directions. The large AI models discussed in the paper and their relevant information are presented in Fig. 1.

## 2 Overview of large AI model development

Large AI models can be classified into two main categories: large foundational models and large industry-specific models $[21]$ . Large foundational models, based on the type of input data they handle, can be further divided into three major types: LLMs $[22]$ , LVMs $[23]$ , and LMMs $[24]$ . Large industry-specific models, on the other hand, are categorized into three levels: L0, L1, and L2, based on the application domain. These include large general-purpose AI models (L0), large industry-specific AI models (L1), and large vertically specialized AI models (L2). The industries involved span across healthcare $[25]$ , finance $[26]$ , smart manufacturing $[27]$ , transportation $[28]$ , education, e-commerce, energy $[29]$ , environmental protection, social media, law $[30]$ , government affairs, and agriculture $[31]$ , as illustrated in Fig. 2.

## 2.1 Large AI models in NLP

## 2.1.1 Traditional language models

Historically, the research paradigm in NLP has evolved from rule-based approaches to statistical methods $[32]$ and from traditional machine learning techniques $[33–35]$ to the current dominance of deep neural networks $[36–38]$ . This evolution mirrors the historical development of LLMs.

The book Introduction to Natural Language Processing provides a definition of language models: “the goal of a language model is to model the probability distribution of natural language” [39]. Specifically, the model aims to construct the probability distribution of word sequences w1, w2,...,wm, i.e., to calculate the likelihood of a given word sequence appearing as a sentence. However, the challenge lies in the massive parameterization of joint probabilities [40], which leads to a huge number of model parameters. A simplified approach to reducing the number of model parameters is to decompose the joint probabilities by using the left-to-right generation process of sentence sequences.

In 1975, Jelinek [41] introduced the N-gram model and applied it to speech recognition tasks [42], also known as the n-gram language model [43, 44]. The probability of a word is influenced by the preceding i-1 words, known as the contextual history. As the number of historical words increases, the amount of data required for this modeling approach also increases exponentially, leading to the “curse of dimensionality” [45]. Furthermore, as the historical word sequences become longer, most of the history may not appear in the training data, resulting in a loss of probability estimation. The higher-order n-gram language models [46] face serious data sparsity issues [47] because the discrete representation of words ignores their similarities. Therefore, neural language models have become a new hotspot of research with the development of neural network technology.

![](images/bc0afcf51f9b15bab4589c5930d4311bf76882a8ef198dbf273966232669dcf0.jpg)  
Figure 1 The most popular large AI models of recent years. This figure shows the main features of these models, their sizes and the years in which they were introduced. It illustrates the evolution of model sizes over time, showing how different models have adapted and changed in response to technological advances and research developments

![](images/e7b0da96e711a2e08622e8a4c2c081b00ec41e10d9cc22c06d6d2e4719b05899.jpg)  
Figure 2 Classification of large AI models and their application domains. Large AI models are categorized based on their input data types and application domains. A distinction is made between foundational models, such as large language models (LLMs), large vision models (LVMs), large multi-modal models (LMMs), and industry-specific models in various sectors such as healthcare, finance, and smart manufacturing

## 2.1.2 Pre-trained language models

Compared to statistical language models [48, 49], neural language models demonstrate stronger learning capabilities, overcoming the curse of dimensionality associated with n-gram language models and significantly enhancing the performance of traditional language models. The advanced structures of neural networks enable them to effectively model long-range contextual dependencies $[50]$ . Language models based on distributed representations, such as word embeddings $[51]$ , have had a profound impact on the field of NLP. These include feedforward neural language models, recurrent neural language models, and long short-term memory (LSTM) $[52]$ recurrent neural network (RNN) $[53]$ language models.

Influenced by the success of pre-training models in the CV domain, a similar paradigm has emerged in NLP, where models are pre-trained on ImageNet $[54]$ to learn feature extraction from large amounts of image data, and then fine-tuned for specific tasks. Methods based on pre-trained language models (PLMs) $[55]$ have gradually become mainstream. In 2018, Peters et al. $[56]$ proposed embeddings from language models (ELMos), which learn a linear combination of the vectors stacked above each input word for each end task instead of learning fixed word representations and then fine-tuning parameters to capture contextual information. In December 2017, Google proposed the Transformer architecture based on the attention mechanism $[9]$ . This architecture is valuable because it is a sequence-to-sequence model entirely based on attention mechanisms, eliminating the dependence on traditional structures such as RNNs $[53]$ , convolutional neural networks (CNNs) $[53]$ , or LSTMs $[52]$ .

In October 2018, Jacob Devlin and colleagues at Google AI Research introduced bidirectional encoder representations from transformers (BERT) [10], which uses a masked language model [57] to pre-train on context prediction tasks. Compared with traditional language modeling methods, BERT can explore the rich semantics implied by context more deeply, significantly improving the performance of NLP tasks.

## 2.1.3 Large language models

LLMs refer to large-scale pre-trained language models with billions of parameters or more. Supported by large text corpora and self-supervised pre-training techniques, LLMs demonstrate powerful capabilities for representing general language and show outstanding performance in addressing complex tasks.

In 2018, OpenAI introduced its LLM named GPT $[11]$ , a generative pre-training model. GPT uses a similar pre-training approach to BERT, but is a generative model $[58]$ capable of generating coherent text. GPT excels in various NLP tasks, demonstrating its robust capabilities in understanding and generating natural language. In February 2019, OpenAI released GPT-2 $[12]$ . GPT-2, also based on the Transformer architecture, inherited the characteristics of the original GPT and was trained on large-scale unlabeled text data $[59]$ . In addition, GPT-2 can optimize model performance through fine-tuning and transfer learned knowledge to downstream tasks [60]. This capability enables GPT-2 to demonstrate strong generality and adaptability to various NLP tasks.

In 2020, Google introduced its T5 model $[61]$ , which adopted a radically different strategy from the previous models by transforming different forms of tasks into conditional generation tasks. Using the same training method and decoding process, T5 can perform different NLP tasks without having to design different model structures and training methods for each task. This one-size-fits-all model significantly reduces the difficulty of transfer learning and multi-task learning across tasks. Building on T5, Google released Flan-T5 $[62]$ , which proposes a multi-task model fine-tuning scheme. Through fine-tuning on a large number of tasks, Flan-T5 demonstrated strong generalization performance and achieved good performance on over 1800 NLP tasks.

In 2022, GLM-130 B [63] was open-sourced by Tsinghua Zhipei AI. It is the largest model in the general language model (GLM) series with 130 billion parameters. Tsinghua University proposed the GLM based on auto-regressive blank filling for three tasks: natural language understanding (NLU) [64], conditional generation tasks [65], and unconditional generation tasks [66]. GLM performed well in all three tasks. In the same year, Google released the PaLM 2 model [67], with a massive parameter count of 5.4 trillion and a token count of 780 billion. When trained via Google's next-generation PathWay distributed training framework [68], the PaLM achieved state-of-the-art performance on hundreds of small-sample language understanding and generation benchmarks.

In 2023, Meta AI introduced the LLaMA model $[69]$ collection, which includes four sizes (7 B, 13 B, 30 B, and 65 B). LLaMA also utilizes the basic Transformer architecture. To enhance training stability, LLaMA employs RMSNorm to normalize the input of each transformer sub-layer instead of normalizing the output. It also replaced absolute position embeddings with rotation embeddings (RoPE) $[70]$ . In July 2023, Meta AI once again open-sourced the more powerful LLaMA-2 $[71]$ , which utilized larger and higher-quality corpora for training, resulting in significant performance improvements. The release of LLaMA also greatly propelled the progress of large AI model research.

## 2.2 Large AI models in computer vision

## 2.2.1 Traditional vision models

In the early stages of CV, the focus was on enabling computers to understand and process images through tasks such as image processing, object recognition, and 3D reconstruction. In the 1970s and 1980s, CV developed independently, leading to key algorithms and models. Research focused on practical applications in areas such as medical image processing and autonomous driving.

Traditional vision models primarily include classic CV methods such as edge detection, feature extraction, and pattern recognition. These models rely on image processing techniques to achieve object recognition and image classification by analyzing features such as color, texture, and shape within images. Common traditional vision models include local binary pattern (LBP) [72], scale-invariant feature transform (SIFT) [73], and histogram of oriented gradients (HOGs) [74].

During this time, CV intersects with fields such as pattern recognition, and computer graphics, which rely primarily on hand-crafted features. However, these features are limited to pixel-level information, resulting in lower model accuracy. Eventually, the field shifted to machine learning, leading to advances in image classification and object detection algorithms, such as support vector machines (SVMs) $[75]$ , decision trees $[76]$ , and AdaBoost $[77]$ .

## 2.2.2 Deep learning vision models

In 2006, deep learning emerged, marking a significant shift in vision models, which had previously been dominated by machine learning. Deep learning gained recognition in 2012 when Alex Krizhevsky won the ILSVRC 2012 competition with the AlexNet model $[78]$ . This milestone brought deep learning into the spotlight, and it has dominated the ILSVRC competitions ever since.

In 2014, the researchers from the University of Oxford launched VGGNet [79] to explore the relationship between the depth of CNNs and performance. VGGNet won the first place in the localization task and the second place in the classification task of the ImageNet competition (ILSVRC 2014).

Also in 2014, GoogLeNet [80], developed by the Google team, won the first place in the classification task of the ImageNet competition (ILSVRC 2014). It introduced the Inception module to expand the network, significantly reducing the number of parameters to just 5 million while outperforming AlexNet and VGGNet.

In 2016, ResNet [81], led by Dr. Kaiming He, achieved a breakthrough by increasing the network depth to 152 layers in the ImageNet classification competition, a significant improvement over VGG's 19 layers [82]. ResNet excelled in both image recognition and object detection competitions and addressed the "degradation" phenomenon in deep networks by introducing shortcut connections, making it easier to train very deep neural networks. This was the first time that neural networks exceeded 100 layers, with some exceeding 1000 layers.

## 2.2.3 Large vision models

With the tremendous success of the Transformer architecture in NLP, researchers have begun exploring its application in CV. The vision Transformer (ViT) model $[83]$ utilizes the Transformer architecture to process images by dividing them into image patches and encoding spatial and contextual information. This approach has shown competitive performance against traditional CNN models in several CV tasks. The ViT model exhibits stronger performance and lower computational cost on large datasets compared to CNNs in image tasks. In addition, researchers have applied the Transformer architecture to various CV domains, including image classification algorithms such as iGPT [84], BiT [85], TNT [86], typical object detection algorithms such as DETR [87], UP-DETR [88], and ACT [89], and typical video processing algorithms such as MEGA [90], STTN [91], and TimeSformer [92].

The emergence of Transformer has overcome the limitations of traditional RNN models in effective parallel computing $[93]$ and mitigated the drawbacks of CNN models in modeling long-range dependencies $[94]$ . By introducing self-attention mechanisms, Transformer can automatically learn the dependencies between different positions in the input sequence, enabling the model to perceive global information more effectively. The Transformer structure also has some notable drawbacks. First, Transformer models lack inductive bias, translation invariance, and local sensitivity, which means they may not generalize well to tasks with scarce data. Second, Transformer models cannot effectively handle high-resolution feature maps, potentially resulting in information loss for small objects in images.

After the introduction of Transformer, the foundational architecture for vision models was established. The attention mechanism replaced CNNs as the mainstream foundational component of models, which facilitated the expansion of models to larger parameter sizes. The inherent multi-modal capabilities of Transformer provided a significant advantage, greatly enriching the application scenarios for large AI models. Inspired by BERT, in 2022, the team led by Dr. Kaiming He proposed MAE $[95]$ , which introduced self-supervised training based on ViT $[96–98]$ , similar to the cloze task in BERT, to gain understanding of images. This can be seen as applying the idea of BERT to the CV field, allowing the entire training process to be extended to unlabeled data. Ultimately, MAE achieved comparable performance to traditional methods with only one-hundredth of the data used for pre-training ViT. Moreover, MAE demonstrated excellent performance in tasks such as object detection, instance segmentation, and semantic segmentation, extending MAE to the realm of videos. VideoMAE adopts a sampling strategy with temporal intervals to achieve more efficient video self-supervised pre-training $[99, 100]$ . Before input encoding, pixel block embeddings of sampled video segments are jointly embedded in the spatiotemporal domain. VideoMAE uses a pipelined masking strategy to address the issue of “information leakage” caused by temporal intervals and temporal correlation in video data $[101]$ . VideoMAE has exhibited good generalizability and transferability to several downstream tasks. While VideoMAE provides an innovative solution to the problem of training effective LVMs with relatively small video datasets, reducing training costs and improving training efficiency, it still results in high computational overhead and memory consumption. Subsequently, Nanjing University proposed VideoMAE v2 $[102]$ based on VideoMAE, which reduced computational resource consumption through dual masking strategies while maintaining the powerful feature reconstruction capabilities of VideoMAE, with the parameter size of the model reaching the level of 1 billion parameters. In 2023, Meta AI introduced the universal semantic segmentation model (SAM) $[103]$ , which, unlike traditional segmentation models, can simultaneously take in the original image and specific cues (points, boxes, shadows, and text), and then output different segmentation result images based on different cues, supporting interactive segmentation with different cues. SAM can be applied to various segmentation scenarios, including interactive segmentation, edge detection, super-resolution, object generation, foreground segmentation, semantic segmentation, instance segmentation, and panorama segmentation. In addition, SAM contributed a large-scale segmentation dataset, SA-1B, consisting of 1 billion masks and 1.1 million images. While SAM has advanced the development of large CV models, its segmentation results lack semantic meaning, and the types of cues are limited to points, boxes, and text. SEEM $[104]$ builds a more versatile segmentation system that can segment all objects with semantic meaning through a pretrained model and is applicable to all types of interaction and cue combinations.

In April 2021, Huawei unveiled the Pangu large AI model, which boasted over 3 billion parameters and was one of the largest vision models at the time. To meet the demands for different model sizes and operating speeds, the Pangu model uses an adaptive approach to adapt to different scales. In addition, the model utilizes hierarchical semantic alignment and semantic adjustment algorithms to achieve better separability in shallow features, significantly enhancing the capability of few-shot learning $[105]$ , which has brought it to the forefront of the industry. Addressing the challenges of deploying pre-trained large AI models, Baidu proposed the unified feature optimization (UFO) technique $[106]$ , which balances the cost and deployment efficiency of large AI models while fully leveraging big data. The Baidu UFO large AI model is the largest vision multitask model in the industry, with 17 billion parameters. Covering over 20 basic CV tasks, including fine-grained classification of faces, human bodies, vehicles, commodities, and food, a single model achieves state-of-the-art performance on 28 public test sets. UFO trains a powerful universal model by using data from multiple tasks, which can be directly applied to handle various tasks. This approach not only enhances the effectiveness of individual tasks by leveraging cross-task information but also eliminates the need for fine-tuning downstream tasks. Shanghai Artificial

Intelligence Laboratory, in collaboration with SenseTime, The Chinese University of Hong Kong, and Shanghai Jiao Tong University, jointly introduced the new generation of general-purpose vision technology, “INTERN” [107]. This framework aims to systematically address a series of bottleneck issues in the current field of AI vision, such as task generalization, scene adaptation, and data efficiency. Launching “INTERN” enables the industry to obtain AI models capable of handling various downstream tasks at a lower cost, with its strong generalization capabilities supporting applications in smart cities, smart healthcare, autonomous driving, and other scenarios with large amounts of small data, zero data, and other sample-deficient and long-tail needs.

Due to limitations such as high-quality datasets, training resources, and generalization performance, the field of vision models still lacks a powerful model application such as ChatGPT. To address this issue, future efforts need to focus on integrating and enriching high-quality vision datasets, promoting the fusion of vision vertical models across different domains, expanding the breadth of model knowledge, and fully unleashing the potential of LVMs. It is imperative to develop and introduce more versatile and human-like LVMs to excel in various vision domain tasks.

## 2.3 Large multi-modal models

LMMs $[108]$ refer to large-scale deep learning models capable of handling various types of data, such as text, images, audio, and more. These models typically integrate techniques from fields such as NLP, CV, and speech processing, enabling them to simultaneously process and understand multiple types of data and achieve superior performance in a variety of tasks. LMMs aim to simulate human perception and understanding, as humans typically use multiple senses and data sources when processing information. These models can accept input data from different modalities and process and learn within a unified framework, thus enabling cross-modal information fusion and interaction $[109]$ . LMMs demonstrate excellent performance in numerous tasks, including image classification, vision question answering $[110]$ , image generation, text-to-image generation, and more. Currently, most multi-modal models include only text and image modalities. These multi-modal models can be categorized into text-conditioned image models, image-conditioned text models, and text-to-image models, based on how the modalities are integrated within the model.

## 2.3.1 Text-to-image models

The text-conditioned image (Text2Image) large AI models refer to models that generate corresponding images based on the text provided by the user. Prior to the introduction of diffusion models $[111]$ , models based on generative adversarial networks (GANs) $[112]$ have been the mainstream approach for image generation. Building upon diffusion models, OpenAI proposed the GLIDE model with 3.5 billion parameters [113], while contrastive learning models similar to CLIP [114] have been shown to effectively learn image representation and capture semantic and stylistic features. Therefore, the DALLE-2 model [115] combines CLIP and diffusion models to generate text-conditioned images or videos. In addition, Rombach et al. [116] introduced the stable diffusion model with 1.45 billion parameters, which is a potential diffusion model for text-to-image generation. Based on previous work such as DDPM [117] and latent diffusion model (LDM) [111], stable diffusion is built upon LDM, with the main difference being the replacement of the original conditional mechanism with the powerful CLIP model, trained on a larger dataset LAION-5B, and with support from stability AI's computing power and LAION's massive data. Stable diffusion can train latent diffusion models on $512 \times 512$ images from a subset of the LAION-5B database. The LAION-5B database contains 5.85 billion CLIP-filtered image-text pairs, which is 14 times larger than LAION-400M and is the world's largest-scale, multi-modal text-image dataset, totaling 80 terabytes of data. It provides subsets and models for different research directions, including subsets such as pornography image filtering, watermark image filtering, high-resolution images, and aesthetic images. Similar to Google's Imagen, the stable diffusion model utilizes a frozen CLIP ViT-L/14 text encoder to adjust the model based on text prompts. Meanwhile, Google proposed the Imagen model with 2 billion parameters [118], which combines the powerful capabilities of Transformer language models and high-fidelity diffusion models, providing unprecedented realism and language understanding in text-to-image synthesis. The emergence of these models signifies the development of diffusion models in the field of text-conditioned image large AI models, providing more robust and efficient solutions for text-to-image generation tasks.

## 2.3.2 Image-to-text models

The image-conditioned text (Image2Text) large AI models refer to models that generate corresponding text based on the images provided by the user. Widely applied in the field of optical character recognition (OCR) $[119]$ , these models are more challenging than simply extracting text from images because they require understanding the input image and providing the corresponding textual interpretation. Microsoft proposed the GIT model with 0.7 billion parameters in 2022 $[120]$ . In 2023, CogVLM developed by Tsinghua University and Zhipu AI achieved deep fusion of vision and language features without sacrificing any NLP task performance $[121]$ . The trained CogVLM-17B is currently ranked first on the authoritative multi-modal academic leaderboard, achieving first or second place results on 14 datasets. The shortcomings of current mainstream shallow alignment methods lie in the lack of deep fusion between visual and language information. CogVLM addresses this by introducing a trainable vision expert module in Attention and FFN layers $[121–123]$ , which separately processes image and text features and utilizes new QKV matrices and MLP layers at each level. The introduction of the vision expert module aims to bridge the gap between pre-trained language models and image encoders. Recently, OpenAI presented the large AI model GPT-4 $[124]$ , which also has the ability to take images as input and output corresponding textual explanations.

Previously, OpenAI unveiled GPT-4, which has powerful multi-modal understanding capabilities, and sparked excitement and imagination about its image understanding and analysis abilities. However, at that time, OpenAI had not made the image recognition functionality of GPT-4 available to users. In response, a research team from King Abdullah University of Science and Technology (KAUST) open-sourced a comparable version called MiniGPT-4 [125]. MiniGPT-4 aims to align visual information from a pre-trained visual encoder with an advanced LLM. Specifically, it uses a single projection layer to align the frozen visual encoder from BLIP-2 with the frozen LLM, Vicuna. The main objective of the model is to bridge the gap between the visual encoder and the LLM using a linear mapping layer. MiniGPT-4 demonstrates excellent multi-modal capabilities, as evidenced by official use cases where it can create website codes from handwritten drafts, generate detailed image descriptions, write stories and poetry based on images, provide solutions to questions depicted in images, and generate recipes based on food photos.

The emergence of these models signifies progress in the field of image-conditioned text generation, providing more powerful and efficient solutions for the task of image-to-text generation.

## 2.3.3 Image-to-text models

The term “text-image large AI model” typically refers to models that take both images and text as input and are widely used in vision-language pre-training tasks. Unlike single-language or single-vision pre-training, multi-modal joint pre-training can provide richer information to the model, thereby enhancing its learning capabilities. One of the representative works is the CLIP model proposed by OpenAI in 2021 [126], which focuses on the semantic information of labeled text rather than simply mapping it to numbers, providing a new perspective for action recognition. Modeling the task as a video-text matching problem within a multi-modal learning framework, this framework enhances video representation with more semantic language supervision, enabling zero-shot action recognition without further labeled data or parameter requirements. Similar to the CLIP model, Google proposed the ALIGN model based on noisy text supervision $[127]$ , which uses a noisy dataset of over 1 billion image-text pairs and learns to align image-text pairs based on contrastive learning loss. This approach allows the model to learn the correlation between images and text from large-scale data, thereby achieving more accurate and efficient alignment of images and text. In 2022, Salesforce further proposed the BLIP model $[128]$ , which designs a Captioner to synthesize text for noisy text data and filters out noisy text. However, the parameter size of these multi-modal pre-training models is relatively small and has not reached the billion level. In 2022, Microsoft proposed the BEiT large-scale vision-language pre-training model with a parameter size of 1.9B $[129]$ . Google proposed the PaLI model with a parameter size of up to 17B $[130]$ . In addition to pre-training tasks, vision-language models can also be applied to segmentation tasks. Google combined the language model PaLM with the vision model ViT-22B $[131]$ to propose the large multi-modal model PaLM-E $[132]$ , with a parameter size of 562B. This model not only understands images, but also understands and generates speech, and executes various complex robot instructions without the need for retraining.

In 2023, LLaVA was introduced by Liu et al. [133] and included two versions: LLaVA 1.0 and 1.5. The model features 7 billion parameters and enables research groups, companies, and even individuals to build their own domain-specific multi-modal models due to its straightforward network architecture and relatively low fine-tuning costs. LLaVA is an end-to-end trained large multimodal model that connects a visual encoder with LLM for general visual and language understanding. LLaVA demonstrates impressive multi-modal conversational capabilities, occasionally exhibiting performance comparable to GPT-4v on unseen images and instructions. It achieved a relative score of $85.1\%$ on a synthetic multimodal instruction-following dataset compared to GPT-4. Approximately six months after the release of LLaVA 1.0, the team launched LLaVA 1.5 [134]. LLaVA 1.5 attained state-of-the-art levels on 11 benchmark tests, surpassing methods that utilized billion-scale datasets by making simple modifications to the original LLaVA with approximately one million data points. In addition, there are related works based on LLaVA, such as LLaVA-Med [135], which adapts LLaVA for the biomedical field, continuing the two-stage training approach of LLaVA while incorporating an additional fine-tuning phase on downstream datasets.

In 2023, InstructBLIP [136] was launched as a continuation of the multi-modal work by the BLIP author team. The architecture of InstructBLIP is similar to that of BLIP-2, and it was developed through instruction-aware fine-tuning of the BLIP-2 model. InstructBLIP initializes from the pre-trained BLIP-2 model and consists of an image encoder, a large LLM, and a Q-Former. During the instruction fine-tuning phase, only the Q-Former is trained while freezing the parameters of the image encoder and LLM. The authors converted 26 datasets into a format suitable for instruction fine-tuning, dividing them into 13 held-in datasets for instruction fine-tuning and 13 held-out datasets for evaluating zero-shot capabilities. The model achieved state-of-the-art performance on multiple validation sets, significantly enhancing the zero-shot generalization ability of multi-modal models.

However, native LLMs exist only in a text-only environment and lack the ability to handle other common modalities such as images, voice, and video, which significantly limits their range of applications. In 2023, the Qwen-VL series $[137]$ was launched, comprising two versions: Qwen-VL and Qwen-VL-Chat. The key idea behind the Qwen-VL series is to combine text and images for joint training, enabling multi-modal perception and understanding. Qwen-VL utilizes a LLM as its foundational component, initializing from the pre-trained weights of Qwen-7B. The visual encoder of Qwen-VL employs the ViT architecture, utilizing the pre-trained weights of OpenClip's ViT-bigG for initialization. During model training and inference, input images are adjusted to a specific resolution. The Qwen-VL series consistently ranks at the top of various benchmark tests, supporting multilingual dialogue, multi-image interleaved dialogue, Chinese localization, and fine-grained recognition.

To bridge visual models with LLM, existing vision-language joint models (VLLMs) often employ lightweight "binding" layers, such as QFormer or linear projections, to align the features of visual and language models. Chen et al. [138] designed a large-scale vision-language foundational model, InternVL, which extends the parameters of the visual base model to 6 billion and progressively aligns it with the LLM. Unlike traditional approaches that rely solely on a visual backbone or dual-encoder models, InternVL uses a visual encoder called InternViT-6B and a language middleware named QLLaMA. QLLaMA is a language middleware with 8 billion parameters, initialized using a multi-lingual version of LLaMA. It provides robust multi-lingual representations for image-text contrastive learning or serves as a bridge between the visual encoder and an existing LLM decoder. To align these two large components, which differ in both modality and structure, the model introduces a progressive alignment training strategy. This strategy begins with contrastive learning on large-scale noisy data and gradually transitions to generative learning on more refined, high-quality data. InternVL is widely applicable to 32 general vision-language benchmarks, including visual perception tasks such as image-level or pixel-level recognition, as well as zero-shot image/video classification and zero-shot image/video-text retrieval. In addition, when combined with an LLM, it can create multi-modal dialogue systems with strong visual capabilities.

Multi-modal data fusion and alignment is a complex and challenging task due to the differences in data representation between different modalities $[139]$ . LMMs typically have massive parameter sizes and complex computational structures, posing significant challenges in terms of computational resource requirements. In situations with scarce or unevenly distributed data, the generalization ability of LMMs may be compromised. These models often exhibit high complexity, making it difficult to explain their internal decision-making processes and feature representation $[140]$ .

## 3 Large AI model architectures 3.1 Self-attention

The self-attention mechanism is a machine learning technique for processing sequential data $[141]$ . Self-attention allows the model to dynamically assign weights to different positions in a sequence based on their importance, modeling global dependencies instead of relying on fixed-size windows or fixed-length memories such as traditional RNNs or CNNs. In self-attention, the importance of each value for a given query is computed using the correlation between queries, keys, and values. These weights are then used to perform a weighted sum of the values, producing the final self-attention representation. The advantages of the self-attention mechanism lie in its ability to capture long-range dependencies, its advantage in parallel computation, and its lack of limitation by sequence length. Therefore, it is widely used in NLP, image processing, and other sequence data processing tasks.

## 3.2 Multi-head self-attention

The multi-head self-attention mechanism is an attention mechanism used for processing sequential data, widely employed in deep learning models, especially in NLP and language modeling tasks. It is an extension of the self-attention mechanism, allowing the model to compute multiple self-attention modules simultaneously in different representation subspaces. The main idea is to map the input sequence into multiple representation spaces, compute self-attention in each, and then combine the results.

The advantage of the multi-head self-attention mechanism lies in its ability to capture complex dependencies between different positions in the input sequence and semantic information in different representation spaces. By computing multiple heads in parallel, significant speed-up in computation can be achieved, enhancing the model's learning efficiency. Therefore, the multi-head self-attention mechanism has shown promising results in various sequence modeling tasks, such as language modeling, machine translation, and text classification.

## 3.3 Transformer

The Transformer architecture typically consists of multiple stacked encoders and decoders. Each encoder comprises two fundamental modules: the multi-head self-attention (MSA) and the feed forward network (FFN). The MSA module uses the self-attention mechanism to learn internal relationships within the input sequence. It allows the model to attend to other positions in the input sequence, improving context understanding. By introducing more nonlinear features, the FFN module helps the model learn more complex functional relationships. Both the MSA and FFN modules utilize residual connections and layer normalization (LN) structures. Residual connections enable information to flow directly between different layers of the model, alleviating the vanishing gradient problem $[142]$ and speeding up the training process. Layer normalization helps accelerate convergence and improve training stability, making it easier for the model to learn and generalize.

In the ViT, the input consists of vectors of two-dimensional image patches instead of one-dimensional language embedding sequences used in the original Transformer. The input embedding vector of the ViT combines image patch embeddings, position encodings, and category embedding vectors. In this way, the ViT can process image data and utilize methods such as the self-attention mechanism to learn feature representations of the image and relationships between pixels.

The Transformer architecture uses self-attention to handle information from different positions simultaneously, addressing the long-range dependency problem of traditional RNNs. The self-attention mechanism allows the model to process different positions in the input sequence in parallel, resulting in high parallelism during training and greatly improving training efficiency. The success of the Transformer architecture has laid the foundation for the rapid development of large AI models, enabling researchers to design and train models with larger parameter sizes and better performance.

## 3.4 Fine-tuning of large AI models

Large AI model fine-tuning $[143]$ is a technique that involves utilizing pre-trained large neural network models and fine-tuning them on specific tasks or domain data. The basic idea is to leverage the knowledge learned by the model on large-scale data during pre-training and adapt it to the specific requirements of a task or domain by fine-tuning it on a relatively smaller dataset. The key steps in fine-tuning include selecting a pre-trained model, preparing the data, modifying the model architecture if necessary, fine-tuning the model, evaluating performance $[144]$ , and adjusting and optimizing, and deploying the model. The advantages of this technique include leveraging the generalization capability of large-scale pre-trained models, improving data efficiency, accelerating the model training process, and adapting to the requirements of different tasks and domains.

Several common fine-tuning techniques include fine-tuning, prefix tuning $[145]$ , P-tuning v2 $[146]$ , and Deep-Speed ZeRO $[147]$ . Compared to traditional fine-tuning methods, Prefix Tuning optimizes only a small learnable continuous task-specific vector (i.e., prefix) when adjusting the model, rather than the entire model's parameters $[148]$ .

P-tuning v2 is mainly based on P-tuning and prefix-tuning techniques and introduces optimization strategies such as deep prompt encoding and multi-task learning $[149]$ . Experimental results have shown that even fine-tuning only 0.1% of the parameters, P-tuning v2 achieves performance comparable to fine-tuning across language models of different parameter scales, ranging from 330M to 10B. This indicates that the optimization strategies adopted by P-tuning v2 have a significant effect on improving model performance.

DeepSpeed's 3D parallelism simultaneously addresses two main challenges in training trillion-parameter models: memory efficiency and computational efficiency. This allows DeepSpeed to scale to accommodate the largest models in memory while maintaining training speed. The combination of DeepSpeed and ZeRO enables full-parameter fine-tuning. While ZeRO's functionality is primarily for training and does not substantially aid inference, with the development of DeepSpeed to ZeRO-3, it can also be used for inference because it allows large AI models to be loaded across multiple GPUs, which is impossible on a single GPU. Although full-parameter fine-tuning using DeepSpeed may have high memory requirements and slower training speeds, it remains a highly effective method.

In addition, some fine-tuning techniques for large models are also highly representative, which are discussed in detail below.

Low-rank adaptation (LoRA) is a method used for fine-tuning large pre-trained language models such as GPT-3 or BERT. Its core idea is to add small, low-rank matrices to the critical layers of the model to adjust its behavior, rather than directly altering the entire model structure. The advantage of this approach is that it allows effective model tuning without significantly increasing the computational load, while maintaining the original performance. In large models such as GPT, the weight matrices to be fine-tuned are first identified, usually located in the model's multi-head self-attention and feed-forward neural network parts. Two low-rank matrices, denoted as A and B, are introduced. These matrices are much smaller in dimension than the original weight matrices. The LoRA method does not directly modify the original extensive weights of the model. Instead, low-rank matrices are introduced into the critical parts of the model, and effective weight adjustments are made through the product of these matrices. This approach allows the model to be better adapted to the specific language and terminology used in fields such as healthcare without the need for extensive weight adjustments and retraining.

Quantized low-rank adaptation (QLoRA) is an efficient model fine-tuning method that introduces a deep quantization process based on LoRA. QLoRA uses a novel high-precision quantization technique to quantize the pre-trained model to 4 bits. This technique includes a low-precision storage data type (4-bit NormalFloat, abbreviated as NF4) and a computational data type (16-bit BrainFloat). During training, QLoRA first loads the model in 4 bits and then dequantizes the values back to bf16 for training. Although quantization typically results in performance loss due to reduced model precision, this method can substantially reduce memory and computational demands for large models, making deployment and training feasible in resource-constrained environments.

Adapter tuning, similar to LoRA, aims to adapt the model to new tasks without changing the original parameters of the pre-trained model. Starting with a large pre-trained model such as BERT or GPT, which has already learned a vast amount of language features and patterns, small neural network modules called “adapters” are inserted into each layer or selected layers of the model. The adapter parameters are trained based on the specific task data, allowing the adapters to learn how to adjust the model’s behavior according to the task. This allows the model to be fine-tuned for each specific task without affecting the overall performance of the other parts of the model.

Instruction tuning is a widely applied technique for fine-tuning large models, where models are further trained on datasets consisting of (instruction, output) pairs. In this context, “instruction” represents human commands, and “output” refers to the desired response that follows those commands. This process helps bridge the gap between the next-word prediction goal of LLMs and the objective of having LLMs follow human instructions. Instruction tuning can be considered a specialized form of supervised fine-tuning (SFT). However, there are key differences in their objectives. SFT involves fine-tuning pre-trained models using labeled data to enhance their performance on specific tasks. In contrast, instruction tuning focuses on further training LLMs on datasets of (instruction, output) pairs to improve their capability and controllability. The unique aspect of instruction tuning lies in its dataset structure, which consists of paired human instructions and the expected outputs. This structure emphasizes enabling the model to understand and follow human commands. While both instruction tuning and SFT share similar goals and methods, the specific data structure and task focus of instruction tuning distinguishes it as a unique subset of SFT, focused on improving the model's ability to follow human instructions.

![](images/fc0c3d39cfeae6bd0c8e1d0005f32e8d3730ad32004962fe7138fe0d07e68adf.jpg)  
Figure 3 Large AI model training. The essential components required to train large AI models include datasets, algorithm architectures, computational resources, and deep neural network frameworks. We emphasize the interplay between these components and their collective impact on the training process

For example, HINT $[150]$ combines the generalization advantages of instruction tuning with the efficiency of on-demand fine-tuning, avoiding the need to repeatedly process lengthy instructions. The core of HINT lies in the hypernetwork, which generates parameter-efficient modules for LLM adaptation based on natural language instructions and a small number of examples. The hypernetwork first converts the instructions and examples into encoded instructions, and then uses a pre-trained text encoder and a cross-attention-based parameter generator to generate adapters and prefix parameters. These generated adapters and prefixes are then inserted into the backbone as efficient tuning modules. During inference, the hypernetwork only performs a single inference per task to generate the adaptive modules. Unlike conventional fine-tuning or input concatenation methods, HINT can integrate long instructions and additional few-shots without increasing computational overhead.

LOw-Memory Optimization (LOMO) [151] achieves full-parameter fine-tuning of LLMs under limited computational resources by merging gradient computation and updates. Its core approach is to combine gradient calculation and parameter updates into a single step during backpropagation, eliminating the need to store entire gradient tensors. By storing only one parameter's gradient at a time, it significantly reduces memory usage for gradients. LOMO stabilizes training through gradient clipping, a separate gradient norm calculation channel, and dynamic loss scaling. The integration of activation checkpointing and ZeRO optimization methods further reduces memory usage.

## 4 Large AI model training and deployment

Training of large AI models consists of four main components: dataset, algorithm architecture, computational resources, and deep neural network frameworks $[152–154]$ , as shown in Fig. 3. The quality, diversity, and scale of the dataset all have significant impacts on the model's performance and generalization ability. Algorithm architecture refers to the specific algorithms and methods used for training and optimizing the model. Commonly used algorithm architectures for training large AI models include various neural network structures in deep learning, such as CNN, RNN, and Transformer, among others.

Large AI model training requires significant computational resources, including CPUs, GPUs, or dedicated accelerators (such as TPUs). In general, employing distributed computing can better utilize computational resources and accelerate the model training process. Deep neural network frameworks are software toolkits for building and training deep learning models, such as TensorFlow $[155]$ , PyTorch $[156]$ , and Keras $[157]$ . These frameworks provide rich neural network model structures, optimization algorithms, and training tools, greatly simplifying the process of model construction and training.

## 4.1 Data collection for training

Publicly available datasets $[158–160]$ used for training large AI models mainly include resources such as the BookCorpus $[161]$ for books, CommonCrawl for web crawling, Twitter for social media, and GitHub for large-scale public code repositories.

Most of the publicly available resources mentioned above consist of general data with only a small amount of specialized data. Due to limited training data in specialized fields, large AI models often struggle to meet the needs of specific professional domains. To equip general large AI models with the same capabilities as vertical domain large AI models, the collection and organization of training data are crucial. This can be achieved through the following methods.

1) Simulating real-world scenarios using virtual engines to provide sufficient data for training and testing large AI models [162–165]. Training and testing in virtual environments can significantly reduce the risks and costs of real-world deployment, while enabling faster iteration and optimization of models.

2) Utilizing excellent generative models to synthesize a large number of images, texts, and other data is an effective method that can provide more training data for various machine learning tasks. Recently, the University of Hong Kong and ByteDance used the text-to-image generation model (GLIDE) [166] to generate a large number of synthetic images and applied these synthetic data to promote image recognition tasks and pre-training of large AI models.

## 4.2 Large AI model training

The enormous number of parameters has significantly increased the training time of large AI models, leading to a significant increase in computational costs $[167]$ . According to a report published by Guosheng Securities $[168]$ , the cost of training GPT-3 is estimated to be approximately 1.4 million per session. For larger LLM models, the training cost ranges from 2 million to 12 million, including GPU costs, data center costs, labor costs, and other hardware costs.

It is now necessary to reconsider the training architecture of large AI models, the choice of parallel strategies, and efficient data storage and communication methods. Currently, several training frameworks have emerged in the field of large AI models. Some of the more well-known ones include Microsoft's DeepSpeed and NVIDIA's Megatron-LM $[169]$ . DeepSpeed is a distributed training framework for large AI models developed by Microsoft, compatible with PyTorch. The first version of this framework is based on ZeRo memory optimization technology, and subsequent versions have added optimizations such as ZeRO++ $[170]$ , ZeRO-Offload $[171]$ , and gradient checkpointing. DeepSpeed has been used for training multiple large AI models, such as literature $[172]$ and BLOOM $[173]$ . Megatron-LM is a distributed training framework based on PyTorch developed by NVIDIA, specifically designed for training large AI models based on Transformer. Megatron-LM provides various distributed training optimization techniques, including data parallelism, pipeline parallelism, and tensor parallelism.

In the future, to better support the training of large AI models, researchers will need to explore how to deeply integrate various parallel acceleration strategies. To explore the intelligent adaptation of training strategies based on the characteristics and training needs of large AI models, we introduce the following automated mechanisms for strategy selection and adjustment.

1) Model feature analysis. For different types of models, feature analysis can be conducted to determine suitable parallel acceleration strategies. For instance, for models with large parameter counts and deep layers, strategies such as model parallelism or pipeline parallelism may be more appropriate.

2) Dynamic adjustment of training requirements. As training progresses, the model's demands and performance may change. Therefore, it is necessary to dynamically monitor and adjust parallel acceleration strategies during training to maximize efficiency and performance [174].

3) Hardware environment awareness. Given the characteristics and limitations of different hardware environments, intelligent selection of parallel acceleration strategies suitable for the current hardware is essential for optimal performance [175].

4) Performance monitoring and tuning.
Performance metrics are continuously monitored during the training process, and adjusted and optimized based on real-time performance data to maintain high efficiency and performance throughout training $[176, 177]$ .

## 4.3 Large AI model deployment

In today's information age, the application of large AI models has penetrated various fields such as recommendation systems and medical diagnosis, as shown in Fig. 4. By using the “Enlightenment” large AI model, the Smart Source Research Institute has developed an advanced digital sign language generation system that automatically converts text content into sign language videos [178]. Huawei's Pangu large CV model, which focuses on the intelligent inspection of unmanned aerial vehicle (UAV) power scenarios [179], addresses two main challenges. The first is efficient data labeling. They used massive amounts of unlabeled power data for pre-training and combined a small number of labeled samples for fine-tuning. This method increases the sample selection efficiency by approximately 30 times. The second challenge is generality and multi-defect recognition. The Pangu large CV model can adapt to over 100 types of defects, replacing over 20 small models, thereby reducing model maintenance costs and increasing average accuracy by 18.4%. In addition, development costs were reduced by 90%. These advantages position the Pangu large CV model with significant application potential in the field of UAV power intelligent inspection.

The Kunlun Wanwei Tiangong large AI model is a powerful AI search engine $[180]$ and a conversational AI assistant. It possesses various functionalities and capabilities, including NLP, intelligent interaction, personalized AI search, smart Q&A, chat interaction, text generation, code writing, and language translation. Furthermore, Tiangong has a rich knowledge base covering various fields such as science, technology, culture, arts, and history.

![](images/fc811ed37796811ac8ec72b3b1829543e879c1b3b0d49dfb459b656282b4c331.jpg)  
Figure 4 Relevant application areas of current large AI models. Examples include NLP, CV, recommendation systems, and medical diagnosis, illustrating the broad impact and versatility of these models across different domains

In terms of smart energy, Baidu and State Grid, have built a text sample library and an industry knowledge graph with tens of millions of energy texts based on Baidu's "Wenxin" series of large AI models $[181]$ . By jointly training large-scale NLP models for the energy industry, the F1 score in the energy industry's word segmentation tasks increased by 9.27% to 92.376%, and in the energy industry's sensitive entity recognition tasks, the F1 score increased by 13.28% to 94.947%. This significantly enhances the automation and intelligence level of equipment and grid operation.

In terms of smart healthcare, Beijing Zhipu Huazhang, Dongfang Hospital, and Beijing University of Traditional Chinese Medicine (TCM), based on the high-precision billion-scale Chinese-English bilingual dense model "GLM-130B" developed by Zhipu Huazhang, have built a digital TCM service platform to explore solutions for AI clinical diagnosis and evaluation of high-risk pulmonary nodules and to realize the intelligent replication of TCM clinical experience.

In terms of smart cities, the Institute of Automation, Chinese Academy of Sciences, and China Railway Construction Corporation, based on the “Zidong Taichu” LMM and cross-modal general AI platform, have jointly developed a fully closed-loop intelligent application system for construction engineering. This system includes functions such as project map indexing, rapid risk communication, and automatic replies, empowering various stages of engineering project design and technical document review and significantly improving the intelligence level of the construction industry.

In terms of autonomous driving, Hesai Zhixing Technology and Great Wall Motor, based on Hesai Zhixing's self-developed DriveGPT, the industry's first automatic driving generative pre-training large AI model, provided rapid discovery of problem scenarios, rapid screening and automatic labeling of scene data, rare scene data generation, and cloud-based simulation evaluation. This approach can effectively save 90% of labeling costs, increase the recognition ability of ambiguous lane lines from about 40% to over 90%, and reduce the prediction error of driving trajectories by nearly 3 times.

In terms of scientific research, Beijing Science Intelligence Research Institute and China Aviation Industry Corporation have jointly developed a high-performance aviation material model based on the independently developed pre-training model (DPA-1) by Beijing Science Intelligence Research Institute. This advanced model can simulate atomic scales up to 10 billion, significantly enhancing the model's transferability and elemental capacity, thereby improving its prediction accuracy.

## 4.4 Deployment compression of large AI models

To address the challenges of deploying large AI modes in real-world scenarios, researchers have used techniques such as inference libraries and low-bit compression to reduce model parameters for cost-effective deployment. Technologies such as NVIDIA TensorRT, ONNX Runtime, and DeepSpeed Inference can be used during the inference phase to optimize models, improve inference speed, reduce latency, optimize resource utilization, and enhance hardware efficiency. NVIDIA TensorRT focuses on accelerating the inference process, particularly on

NVIDIA GPUs. TensorRT provides various optimization techniques, such as layer fusion, memory reuse, dynamic batching, and mixed-precision inference, to improve model efficiency during inference. Mixed-precision inference is a key feature, which reduces computation by converting some operations to FP16 or INT8 while maintaining high accuracy. ONNX Runtime supports the inference of models from various deep learning frameworks such as PyTorch and TensorFlow. It converts models into ONNX format and applies graph optimization techniques, including layer fusion, constant folding, and redundancy elimination, to improve inference performance on different hardware platforms. ONNX Runtime supports multiple acceleration methods, including CPU and GPU acceleration, as well as various hardware architectures such as FPGA and TPU. DeepSpeed Inference $[182]$ is a high-performance deep learning library focused on both training and inference, particularly optimizing inference for LLMs. It reduces inference latency through mixed-parallelism techniques and methods such as zero-offload and quantization-aware training (QAT). DeepSpeed enables inference of models with tens or hundreds of billions of parameters, even under limited resources.

In addition, low-bit compression techniques can be employed to reduce the bit-width (i.e., precision) of model weights and activation values, thereby decreasing the storage requirements and computational complexity of deep learning models. This technology significantly enhances model efficiency when deployed on embedded devices or in resource-constrained environments. For example, GPTQ $[183]$ is a novel one-shot weight quantization method based on approximate second-order information. It can quantize a GPT model with 175 billion parameters in approximately 4 GPU hours, reducing the bit-width of each weight to 3 or 4 bits, with negligible accuracy loss compared to the uncompressed baseline. On the other hand, IR-QLoRA $[184]$ advances the quantization of LLMs through information preservation, promoting highly accurate fine-tuning with LoRA. This work introduces an information-theoretic perspective to examine and measure the quantization of large models through theories related to information entropy. In addition, information elastic connections based on fine-tuning allow LoRA to utilize different information for flexible representation transformations. Comprehensive experiments indicate that IR-QLoRA significantly increases the accuracy of LLaMA and LLaMA2 series of models at 2-4 bit widths. Moreover, IR-QLoRA demonstrates remarkable versatility, seamlessly integrated with various quantization frameworks such as NormalFloat and Integer Quantization, while providing widespread accuracy improvements. It significantly improves the quantization accuracy of LLM's LoRA fine-tuning, facilitating practical deployment in resource-constrained scenarios.

BiLLM $[185]$ achieves extreme quantization, compressing the space occupied by each parameter to 1.1 bits. In the OPT model family, BiLLM achieves the most extreme post-training compression of LLMs with an average weight size of 1.1 bits, using 1 bit to approximate parameters in the network and 2 bits to represent some weights that significantly affect performance. On the Llama series of models, the BiLLM outperforms the full-precision OPT-66B model at 1.08 bits. In terms of efficiency, BiLLM can complete the binarization of a 7-billion LLM in half an hour on a single GPU. BiLLM employs a novel binary residual approximation strategy. By thoroughly analyzing the weight distribution characteristics of LLMs, the system can accurately identify and selectively structure key weights. This strategy effectively reduces the loss incurred during compression, ensuring high model performance even at extremely low bit widths. For the non-significant weight portions, BiLLM introduces an optimal segmentation search algorithm. This method leverages the bell-shaped distribution of weights to accurately group and binarize these parameters, further optimizing the compression effect while maintaining accuracy. The application of BiLLM has significant implications for deployment. Cloud service providers can utilize BiLLM to reduce data transmission costs, enhancing the accessibility and responsiveness of LLMs. Mobile application developers and companies in the Internet of Things (IoT) sector can run complex NLP tasks, such as speech recognition and chatbots, on limited hardware resources using the compressed models from BiLLM without relying on powerful central processors.

## 5 Pros and cons of large AI models and development trends

## 5.1 Advantages of large AI models

Compared to traditional shallow models, large AI models have unique advantages because of their powerful learning and expressive capabilities.

1) Ability to handle complex tasks. Large AI models perform exceptionally well across various NLP tasks. LVMs can easily adapt to a variety of visual tasks. Their large number of parameters allows them to learn more detailed information, enabling them to better understand and process input data, and providing advantages in areas such as natural language understanding and generation, and image recognition and generation.

2) Enhanced model performance. The extensive number of parameters in large AI models enables them to incorporate more feature information. Among these, LMMs are capable of simultaneously processing multiple types of data to learn a wider range of feature information and achieve better performance in a variety of tasks such as image

captioning, visual question answering, and cross-lingual information retrieval. Moreover, LMMs also offer opportunities for numerous downstream zero-shot inference applications. This provides solutions for specific scenarios such as open vocabulary classification, detection, and segmentation tasks. Compared to small models, on the same dataset, large AI models can better fit the data, reducing overfitting and underfitting, hence demonstrating higher accuracy in tasks such as prediction and classification.

3) Transfer learning ability. Large AI models have strong transfer learning capabilities, enabling knowledge sharing and transfer across different tasks. This capability allows large AI models to adapt more flexibly to various tasks and datasets, reducing the time and cost of training models from scratch, thereby improving model efficiency and generalization capability.

4) Rapid iteration and experimentation. Although training large AI models requires more computational resources and time, once trained, they can quickly adapt to new tasks or domains through fine-tuning or transfer learning. This flexibility allows researchers and engineers to experiment and iterate more quickly, accelerating the process of innovation and application.

5) Community support and rich resources. Because large AI models are typically developed by large technology companies or research institutions, they benefit from extensive community and resource support. This includes model libraries, tools, documentation, and community support, making it easier for developers to use and deploy large AI models.

6) Higher innovation potential. By learning from large amounts of data, large AI models can discover potential patterns and regularities in the data, and and therefore have greater potential for innovation.

## 5.2 Disadvantages of large AI models

The limitations of large AI models not only limit their feasibility in practical applications, but also pose challenges for their sustainable development and adoption.

1) High computational resource demands. Training large AI models requires significant computing resources, especially GPU or TPU devices. In addition, sufficient memory is needed to store model parameters and intermediate computation results. The inference process of running large AI models also requires significant computational resources, especially in scenarios involving real-time inference or large-scale data processing, which requires even more computational resources.

2) Long training time. During training, model parameters need to be optimized through multiple iterations, which may take weeks or even months. A long training period requires not only substantial computational resources, but also patience and expertise to debug and optimize the model.

3) Prone to overfitting. Large AI models with more parameters are prone to overfitting, performing well on training data but poorly on test data.

4) Poor interpretability. Large AI models typically consist of billions of parameters, making their decision-making processes and prediction results difficult to interpret. The lack of interpretability reduces the credibility of the model, especially in applications such as medical diagnosis and financial risk control, where interpretability is critical.

5) Data privacy and security risks. Large AI models typically require large amounts of training data to achieve good performance, which may involve users' private data [186]. If these data are not properly protected, it can lead to data breaches and security risks. During the training and inference process of the model, there is a risk that data could be maliciously attacked or tampered with, thereby affecting the accuracy and reliability of the model.

6) Environmental impact. Training and inference of large AI models requires significant computing resources, especially GPUs or TPUs. These devices' operation typically requires significant energy consumption. Manufacturing hardware for training and inference can generate industrial and electronic waste, worsening pollution and resource depletion.

7) Social negative impacts. Training data for large AI models can contain bias or imbalance, resulting in models that reflect societal biases and discrimination in decisions and predictions. This can exacerbate social inequality in race, gender, and geography, affecting individuals' rights and opportunities.

8) Challenges of developing LMMs. The development of LMMs faces challenges due to semantic gaps between different modalities, variations in noise levels between different modalities, and information loss when fusing multi-modal information. Differences in modality correlations across tasks or domains hinder direct model transferability. Furthermore, current multi-modal frameworks exhibit limitations. First, dual-tower multi-modal models such as CLIP often rely on large-scale self-supervised learning on rich image and text data, which is primarily based on large-scale contrastive learning and lacks direct generative supervision. This can result in the models lacking expertise or fine-grained understanding of certain tasks. In addition, the use of shared modality embedding spaces may obscure or overlook specific modality information during encoding, leading to information loss and potential feature collapse problems. Second, cross-modal alignment models such as BLIP-2 typically focus on singular image understanding tasks and lack a comprehensive understanding of context. This can lead to suboptimal performance when dealing with more complex multi-modal data. Third, text-driven image generation models such as LDM focus primarily on single tasks such as text generation, overlooking the semantic understanding of images, potentially resulting in poor performance when handling complex relationships between text and images.

In summary, existing LMMs face the following problems.

1) Corpus limitations. Many multi-modal frameworks are trained on limited image-text pairs, potentially restricting their generalization abilities in real-world scenarios.

2) Inconsistent understanding and generation capabilities across modalities. Inconsistencies in information fusion and understanding across different modalities may result in subpar performance in multi-modal scenarios.

3) Lack of true multi-modality. While these frameworks can handle multi-modal inputs, their design and training may not fully exploit inter-modal correlations and complementarities, failing to take full advantage of true multi-modality when processing multi-modal data.

## 5.3 Trends in large AI model development

Since 2018, the parameter indicators of large-scale pre-trained models at home and abroad have been continuously refreshed, and breakthroughs have been achieved with trillions of parameters. The emergence of these super-large pre-trained models has not only driven the advancement of AI technology, but also brought tremendous opportunities and challenges to various industries.

1) Super large AI models. With the development of deep learning algorithms and hardware technology, it is foreseeable that even larger-scale models will emerge in the future. These models may have scales of hundreds of billions or even trillions of parameters such as GPT-4, Turing-NLG. Such models will be able to better capture subtle relationships and complex patterns in data, thereby achieving better performance in NLP, CV, and other areas.

2) Multi-modal fusion. Future large AI models may pay more attention to multi-modal data fusion and learning [187]. In the future, large multi-modal

models will evolve toward integrated generation and understanding. Future large-scale models may also exhibit greater autonomous learning and exploration capabilities, actively acquiring, understanding, and using data from the physical world.

3) Continuous learning and incremental learning. With the successful applications of large AI models in different fields and tasks, continuous learning $[188]$ and incremental learning $[189]$ will become important directions for development. Future large AI models may pay more attention to how to continuously learn and adapt in a constantly changing environment, and how to accumulate experience and knowledge in new tasks and domains. This requires models to have flexible learning capabilities to continuously update and optimize their performance using new data.

4) Self-supervised learning and weakly supervised learning. Self-supervised learning [190] and weakly supervised learning [191] are important directions for the future development of large AI models. Self-supervised learning allows models to learn the inherent structure and patterns in the data by designing appropriate self-supervised tasks. Weakly supervised learning guides the model learning through weaker supervision signals, such as partial annotations and domain knowledge. Such methods can better utilize existing data resources, reduce annotation costs, and achieve better results when data are scarce.

5) Interpretability and fairness. In many practical application scenarios, users are increasingly demanding interpretability and transparency $[192]$ from models, requiring models to provide clear explanations and justifications. At the same time, the fairness of models $[193]$ has also received attention, with a focus on avoiding bias and treating all groups equally.

6) Edge computing and low-resource deployment. Future large AI models focus on efficient deployment and inference on edge devices $[194]$ , meeting practical application needs while maintaining low computational and storage costs. This will require models to have lightweight and efficient characteristics, capable of efficient inference in resource-constrained environments, offering users faster and more intelligent experiences.

## 6 Conclusion

From the early language models to today's super-large pretrained AI models, the number of model parameters has surpassed trillions. This trend has been met with enthusiastic responses from global technology giants. They are investing heavily to advance the development of large AI model technology. However, as large AI models have been widely applied in different domains, they have also posed several challenges in terms of interpretability, high training costs, and potential ethical risks. These challenges not only influence the development of large-scale AI model technology, but also raise important considerations about its applications and implications.

Looking ahead, with the continued evolution of large-scale AI model technology, we can expect more research and exploration to optimize these models. This includes enhancing their interpretability, reducing training costs, and addressing ethical concerns. Meanwhile, the industry will be actively exploring ways to put large AI models into practice to realize their full potential.

## Abbreviations

AI, artificial intelligence; CNNs, convolutional neural networks; CV, computer vision; FFN, feedforward neural network; GLM, general language model; IoT, Internet of things; LLMs, large language models; LM, language models; LMMs, large multi-modal models; LN, layer normalization; LSTMs, long short-term memory; LVMs, large vision models; MSA, multi-head self-attention; NLP, natural language processing; NLU, natural language understanding; OCR, optical character recognition; PLMs, Pre-trained language models; RLHF, reinforcement learning from human feedback; RoPE, rotary position embeddings; RNNs, recurrent neural networks; SVM, support vector machine; TCM, traditional Chinese medicine; UAV, unmanned aerial vehicle; UFO, unified feature optimization; ViT, vision transformer.

## Author contributions

Xiaoguang Tu and Zhi He designed the structure of the article and drafted the manuscript. Yi Huang and Zhi-Hao Zhang collected relevant materials and drew the figures. Ming Yang revised the manuscript. Jian Zhao was in charge of the final proofreading, editing, and submission. All authors made significant contributions to the work. All authors read and approved the final manuscript.

## Funding

This work was supported in part by the National Natural Science Foundation of China (Nos. 62406207 and 62476224), the Project of Basic Scientific Research of Central Universities of China (No. J2023-026), the project of Science and Technology Department in Sichuan Province (No. 25QNJJ5597), the Science and Technology Project of the Tibet Autonomous Region (No. XZ202401ZY0016), and the Project of Sichuan Province Engineering Technology Research Center of General Aircraft Maintenance (No. GAMRC2023YB06).

## Data availability

The dataset generated by this work is not publicly available due to institutional policy. Access to the data may be granted on a case-by-case basis upon request.

## Declarations

## Competing interests

The authors declare no competing interests.

## Author details

$^{1}$ Civil Aviation Flight University of China, College of Aviation Electronics and Electrical, Guanghan 618307, China. $^{2}$ National Key Laboratory of Fundamental Science on Synthetic Vision, Sichuan University, Chengdu 610065, China. $^{3}$ Harbin Institute of Technology, Harbin, 150001, China. $^{4}$ EVOL Lab, The Institute of AI (TeleAI), China Telecom, Beijing 100033, China. $^{5}$ School of Artificial Intelligence, Northwestern Polytechnical University, Xi'an 710072, China.

Received: 14 June 2024 Revised: 20 November 2024  
Accepted: 21 November 2024 Published online: 27 December 2024

## References

1. Janiesch, C., Zschech, P., & Heinrich, K. (2021). Machine learning and deep learning. Electronic Markets, 31(3), 685–695.

2. Liu, W., Wang, Z., Liu, X., Zeng, N., Liu, Y., & Alsaadi, F. E. (2017). A survey of deep neural network architectures and their applications. Neurocomputing, 234, 11–26.

3. Sandjakoska, L., & Stojanovska, F. (2020). How initialization is related to deep neural networks generalization capability: experimental study. In Proceedings of the 55th international scientific conference on information, communication and energy systems and technologies (pp. 163–166). Piscataway: IEEE.

4. Ettaouil, E. H. (2021). Generalization ability augmentation and regularization of deep convolutional neural networks using I1/2 pooling. International Journal on Technical and Physical Problems of Engineering, 13(48), 1–6.

5. Singh, C., Murdoch, W. J., & Yu, B. (2019). Hierarchical interpretations for neural network predictions. In Proceedings of the 7th international conference on learning representations (pp. 1–26). Retrieved November 11, 2024, from https://openreview.net/forum?id=SkEqroOctQ.

6. Wei, J., Tay, Y., Bommasani, R., Raffel, C., Zoph, B., Borgeaud, S., et al. (2022). Emergent abilities of large language models. Retrieved November 11, 2024, from https://openreview.net/forum?id=yzkSU5zdwdD.

7. Swaminathan, S., Dedieu, A., Vasudeva Raju, R., Shanahan, M., Lazaro-Gredilla, M., & George, D. (2023). Schema-learning and rebinding as mechanisms of in-context learning and emergence. In A. Oh, T. Neumann, A. Globerson, et al. (Eds.), Proceedings of the 37th international conference on neural information processing systems (pp. 28785–28804). Red Hook: Curran Associates.

8. Boiko, D. A., MacKnight, R., & Gomes, G. (2023). Emergent autonomous scientific research capabilities of large language models. arXiv preprint. arXiv:2304.05332.

9. Vaswani, A., Shazeer, N., Parmar, N., Uszkoreit, J., Jones, L., Gomez, A. N., et al. (2017). Attention is all you need. In I. Guyon, U. von Luxburg, S. Bengio, et al. (Eds.), Proceedings of the 31st international conference on neural information processing systems (pp. 5998–6008). Red Hook: Curran Associates.

10. Devlin, J., Chang, M. W., Lee, K., & Toutanova, K. (2019). BERT: pre-training of deep bidirectional transformers for language understanding. In J. Burstein, C. Doran, & T. Solorio (Eds.), Proceedings of the 2019 conference of the North American chapter of the Association for Computational Linguistics: human language technologies (pp. 4171–4186). Stroudsburg: ACL.

11. Radford, A., Narasimhan, K., Salimans, T., & Sutskever, I. (2018). Improving language understanding by generative pre-training. Retrieved November 11, 2024, from https://cdn.openai.com/research-covers/language-unsupervised/language\_understanding\_paper.pdf.

12. Radford, A., Wu, J., Child, R., Luan, D., Amodei, D., & Sutskever, I. (2019). Language models are unsupervised multitask learners. Retrieved November 11, 2024, from https://cdn.openai.com/better-language-models/language\_models\_are\_unsupervised\_multitask\_learners.pdf.

13. Bai, Y., Jones, A., Ndousse, K., Askell, A., Chen, A., DasSarma, N., et al. (2022). Training a helpful and harmless assistant with reinforcement learning from human feedback. arXiv preprint. arXiv:2204.05862.

14. Zhang, S., Roller, S., Goyal, N., Artetxe, M., Chen, M., Chen, S., et al. (2022). OPT: open pre-trained transformer language models. arXiv preprint. arXiv:2205.01068.

15. Chowdhery, A., Narang, S., Devlin, J., Bosma, M., Mishra, G., Roberts, A., et al. (2023). PaLM: scaling language modeling with pathways. Journal of Machine Learning Research, 24, 1–113.

16. Sun, Y., Wang, S., Feng, S., Ding, S., Pang, C., Shang, J., et al. (2021). ERNIE 3.0: Large-scale knowledge enhanced pre-training for language understanding and generation. arXiv preprint. arXiv:2107.02137.

17. Wang, S., Sun, Y., Xiang, Y., Wu, Z., Ding, S., Gong, W., et al. (2021). ERNIE 3.0 Titan: exploring larger-scale knowledge enhanced pre-training for language understanding and generation. arXiv preprint. arXiv:2112.12731.

18. Lin, J., Men, R., Yang, A., Zhou, C., Ding, M., Zhang, Y., et al. (2021). M6: a Chinese multimodal pretrainer. arXiv preprint. arXiv:2103.00823.

19. Zeng, W., Ren, X., Su, T., Wang, H., Liao, Y., Wang, Z., et al. (2021). PanGu- $\alpha$ : large-scale autoregressive pretrained Chinese language models with auto-parallel computation. arXiv preprint. arXiv:2104.12369.

20. Ren, X., Zhou, P., Meng, X., Huang, X., Wang, Y., Wang, W., et al. (2023). Pangu- $\Sigma$ : Towards trillion parameter language model with sparse heterogeneous computing. arXiv preprint. arXiv:2303.10845.

21. Gu, Z., Zhu, B., Zhu, G., Chen, Y., Tang, M., & Wang, J. (2024). AnomalyGPT: detecting industrial anomalies using large vision-language models. In M. J. Wooldridge, J. G. Dy, & S. Natarajan (Eds.), Proceedings of the 38th AAAI conference on artificial intelligence (pp. 1932–1940). Palo Alto: AAAI Press.

22. Shanahan, M. (2024). Talking about large language models. Communications of the ACM, 67(2), 68–79.

23. Bahng, H., Jahanian, A., Sankaranarayanan, S., & Isola, P. (2022). Exploring visual prompts for adapting large-scale models. arXiv preprint. arXiv: 2203.17274.

24. Liu, W., & Zuo, Y. (2023). Stone needle: a general multimodal large-scale model framework towards healthcare. arXiv preprint. arXiv:2306.16034.

25. Wang, D. Q., Feng, L. Y., Ye, J. G., Zou, J. G., & Zheng, Y. F. (2023). Accelerating the integration of ChatGPT and other large-scale AI models into biomedical research and healthcare. MedComm–Future Medicine, 2(2), e43.

26. Yang, Y., Uy, M. C. S., & Huang, A. (2020). FinBERT: a pretrained language model for financial communications. arXiv preprint. arXiv:2006.08097.

27. Zhang, H., Dereck, S. S., Wang, Z., Lv, X., Xu, K., Wu, L., et al. (2023). Large scale foundation models for intelligent manufacturing applications: a survey. arXiv preprint. arXiv:2312.06718.

28. Zhou, L., Zhang, S., Yu, J., & Chen, X. (2019). Spatial-temporal deep tensor neural networks for large-scale urban network speed prediction. IEEE Transactions on Intelligent Transportation Systems, 21(9), 3718–3729.

29. Devaraj, J., Madurai Elavarasan, R., Shafiullah, G. M., Jamal, T., & Khan, I. (2021). A holistic review on energy forecasting using big data and deep learning models. International Journal of Energy Research, 45(9), 13489–13530.

30. Zhong, H., Guo, Z., Tu, C., Xiao, C., Liu, Z., & Sun, M. (2018). Legal judgment prediction via topological learning. In E. Riloff, D. Chiang, J. Hockenmaier, et al. (Eds.), Proceedings of the 2018 conference on empirical methods in natural language processing (pp. 3540–3549). Stroudsburg: ACL.

31. Abozeid, A., Alanazi, R., Elhadad, A., Taloba, A. I., & Abd El-Aziz, R. M. (2022) A large-scale dataset and deep learning model for detecting and counting olive trees in satellite imagery. Computational Intelligence and Neuroscience, 2022, 1549842.

32. Cambria, E., & White, B. (2014). Jumping NLP curves: a review of natural language processing research. IEEE Computational Intelligence Magazine, 9(2), 48–57.

33. Sharifani, K., Amini, M., Akbari, Y., & Godarzi, A. J. (2022). Operating machine learning across natural language processing techniques for improvement of fabricated news model. International Journal of Science and Information System Research, 12(9), 20–44.

34. Nagarhalli, T. P., Vaze, V., & Rana, N. K. (2021). Impact of machine learning in natural language processing: a review. In Proceedings of the third international conference on intelligent communication technologies and virtual mobile networks (pp. 1529–1534). Piscataway: IEEE.

35. Harrison, C. J., & Sidey-Gibbons, C. J. (2021). Machine learning in medicine: a practical introduction to natural language processing. BMC Medical Research Methodology, 21, 158.

36. Wu, L., Chen, Y., Shen, K., Guo, X., Gao, H., Li, S., et al. (2023). Graph neural networks for natural language processing: a survey. Foundations and Trends in Machine Learning, 16(2), 119–328.

37. Goldberg, Y. (2016). A primer on neural network models for natural language processing. Journal of Artificial Intelligence Research, 57, 345–420.

38. Wang, W., & Gang, J. (2018). Application of convolutional neural network in natural language processing. In Proceedings of the international conference on information systems and computer aided education (pp. 64–70). Piscataway: IEEE.

39. Zhang, Q., Gui, T., & Huang, X. (2023). Introduction to natural language processing. Beijing: Electronic Industry Press.

40. Fine, A. (1982). Hidden variables, joint probability, and the Bell inequalities. Physical Review Letters, 48(5), 291.

41. Jelinek, F. (1976). Continuous speech recognition by statistical methods. Proceedings of the IEEE, 64(4), 532–556.

42. Yu, D., Seltzer, M. L., Li, J., Huang, J. T., & Seide, F. (2013). Feature learning in deep neural networks-studies on speech recognition tasks. arXiv preprint. arXiv:1301.3605.

43. Brown, P. F., Della Pietra, V. J., Desouza, P. V., Lai, J. C., & Mercer, R. L. (1992). Class-based n-gram models of natural language. Computational Linguistics, 18(4), 467–480.

44. Pauls, A., & Klein, D. (2011). Faster and smaller n-gram language models. In D. Lin, Y. Matsumoto, & R. Mihalcea (Eds.), Proceedings of the 49th annual meeting of the Association for Computational Linguistics: human language technologies (pp. 258–267). Stroudsburg: ACL.

45. Verleysen, M., & François, D. (2005). The curse of dimensionality in data mining and time series prediction. In J. Cabestany, A. Prieto, & F. S. Hernández (Eds.), Proceedings of the international work-conference on artificial neural networks (pp. 758–770). Berlin: Springer.

46. Hirsimaki, T., Pylkkonen, J., & Kurimo, M. (2009). Importance of high-order n-gram models in morph-based speech recognition. IEEE Transactions on Audio, Speech, and Language Processing, 17(4), 724–732.

47. Greenland, S., Mansournia, M. A., & Altman, D. G. (2016). Sparse data bias: a problem hiding in plain sight. The BMJ, 353(352), i1981.

48. Bellegarda, J. R. (2004). Statistical language model adaptation: review and perspectives. Speech Communication, 42(1), 93–108.

49. Rosenfeld, R. (2000). Two decades of statistical language modeling: where do we go from here? Proceedings of the IEEE, 88(8), 1270–1278.

50. Graves, A., & Graves, A. (2012). Long short-term memory. In A. Graves (Ed.), Supervised sequence labelling with recurrent neural networks (pp. 37–45). Berlin: Springer.

51. Pelevina, M., Arefyev, N., Biemann, C., & Panchenko, A. (2017). Making sense of word embeddings. arXiv preprint. arXiv:1708.03390.

52. Hochreiter, S., & Schmidhuber, J. (1997). Long short-term memory. Neural Computation, 9(8), 1735–1780.

53. Yin, W., Kann, K., Yu, M., & Schütze, H. (2017). Comparative study of CNN and RNN for natural language processing. arXiv preprint. arXiv:1702. 01923.

54. Deng, J., Dong, W., Socher, R., Li, L. J., Li, K., & Li, F.-F. (2009). ImageNet: a large-scale hierarchical image database. In Proceedings of the IEEE conference on computer vision and pattern recognition (pp. 248–255). Piscataway: IEEE.

55. Hong, T., Kim, D., Ji, M., Hwang, W., Nam, D., & Park, S. (2020). BROS: a pre-trained language model for understanding texts in document. Retrieved Nomber 11, 2024, from https://openreview.net/pdf?id=punMXQEsPr0.

56. Peters, M. E., Neumann, M., Iyyer, M., Gardner, M., Clark, C., Lee, K., et al. (2018). Deep contextualized word representations. In M. A. Walker, H. Ji, & A. Stent (Eds.), Proceedings of the 2018 conference of the North American chapter of the Association for Computational Linguistics: human language technologies (pp. 2227–2237). Stroudsburg: ACL.

57. Felsten, G., & Wasserman, G. S. (1980). Visual masking: mechanisms and theories. Psychological Bulletin, 88(2), 329.

58. Ruthotto, L., & Haber, E. (2021). An introduction to deep generative modeling. GAMM-Mitteilungen, 44(2), e202100008.

59. Zhang, T., & Oles, F. (2000). The value of unlabeled data for classification problems. In P. Langley (Ed.), Proceedings of the 17th international conference on machine learning (pp. 1191–1198). San Francisco: Morgan Kaufmann Publishers.

60. Tang, Z., Wang, D., & Zhang, Z. (2016). Recurrent neural network training with dark knowledge transfer. In Proceedings of the IEEE international conference on acoustics, speech and signal processing (pp. 5900–5904). Piscataway: IEEE.

61. Raffel, C., Shazeer, N., Roberts, A., Lee, K., Narang, S., Matena, M., et al. (2020). Exploring the limits of transfer learning with a unified text-to-text transformer. Journal of Machine Learning Research, 21, 1–67.

62. Chung, H. W., Hou, L., Longpre, S., Zoph, B., Tay, Y., Fedus, W., et al. (2024). Scaling instruction-finetuned language models. Journal of Machine Learning Research, 25, 1–53.

63. Du, Z., Qian, Y., Liu, X., Ding, M., Qiu, J., Yang, Z., et al. (2021). GLM: general language model pretraining with autoregressive blank infilling. In S. Muresan, P. Nakov, & A. Villavicencio (Eds.), Proceedings of the 60th annual meeting of the association for computational linguistics (pp. 320–325). Stroudsburg: ACL.

64. Liu, X., He, P., Chen, W., & Gao, J. (2019). Multi-task deep neural networks for natural language understanding. In A. Korhonen, D. R. Traum, & L. Márquez (Eds.), Proceedings of the 57th annual meeting of the association for computational linguistics (pp. 4487–4496). Stroudsburg: ACL.

65. Keskar, N. S., McCann, B., Varshney, L. R., Xiong, C., & Socher, R. (2019). CTRL: a conditional transformer language model for controllable generation. arXiv preprint. arXiv:1909.05858.

66. Sun, F. K., & Lai, C. I. (2020). Conditioned natural language generation using only unconditioned language model: an exploration. arXiv preprint. arXiv:2011.07347.

67. Anil, R., Dai, A. M., Firat, O., Johnson, M., Lepikhin, D., Passos, A., et al. (2023). PaLM 2 technical report. arXiv preprint. arXiv:2305.10403.

68. Barham, P., Chowdhery, A., Dean, J., Ghemawat, S., Hand, S., Hurt, D., et al. (2022). Pathways: asynchronous distributed dataflow for ML. Proceedings of Machine Learning and Systems, 4, 430–449.

69. Touvron, H., Lavril, T., Izacard, G., Martinet, X., Lachaux, M. A., Lacroix, T., et al. (2023). LLaMA: open and efficient foundation language models. arXiv preprint. arXiv:2302.13971.

70. Su, J., Ahmed, M., Lu, Y., Pan, S., Bo, W., & Liu, Y. (2024). Roformer: enhanced transformer with rotary position embedding. Neurocomputing, 568, 127063.

71. Touvron, H., Martin, L., Stone, K., Albert, P., Almahairi, A., Babaei, Y., et al. (2023). LLaMA 2: open foundation and fine-tuned chat models. arXiv preprint. arXiv:2307.09288.

72. Chen, T., Liu, S., Chang, S., Cheng, Y., Amini, L., & Wang, Z. (2020). Adversarial robustness: from self-supervised pre-training to fine-tuning. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition (pp. 699–708). Piscataway: IEEE.

73. Tao, Y., Xia, Y., Xu, T., & Chi, X. (2010). Research progress of the scale invariant feature transform (SIFT) descriptors. Journal of Convergence Information Technology, 5(1), 116–121.

74. Surasak, T., Takahiro, I., Cheng, C., Wang, C., & Sheng, P. (2018). Histogram of oriented gradients for human detection in video. In Proceedings of the 5th international conference on business and industrial research (pp. 172–176). Piscataway: IEEE.

75. Chandra, M. A., & Bedi, S. S. (2021). Survey on SVM and their application in image classification. International Journal of Information Technology, 13(5), 1–11.

76. Song, Y. Y., & Ying, L. U. (2015). Decision tree methods: applications for classification and prediction. Shanghai Archives of Psychiatry, 27(2), 130.

77. Cao, Y., Miao, Q., Liu, J., & Gao, L. (2013). Advance and prospects of AdaBoost algorithm. Acta Automatica Sinica, 39(6), 745–758.

78. Krizhevsky, A., Sutskever, I., & Hinton, G. E. (2012). ImageNet classification with deep convolutional neural networks. In P. L. Bartlett, F. C. N. Pereira, C. J. C. Burges, et al. (Eds.), Proceedings of the 26th international conference on neural information processing systems (pp. 1106–1114). Red Hook: Curran Associates.

79. Simonyan, K., & Zisserman, A. (2014). Very deep convolutional networks for large-scale image recognition. arXiv preprint. arXiv:1409.1556.

80. Szegedy, C., Liu, W., Jia, Y., Sermanet, P., Reed, S., Anguelov, D., et al. (2015). Going deeper with convolutions. In Proceedings of the IEEE conference on computer vision and pattern recognition (pp. 1–9). Piscataway: IEEE.

81. He, K., Zhang, X., Ren, S., & Sun, J. (2016). Deep residual learning for image recognition. In Proceedings of the IEEE conference on computer vision and pattern recognition (pp. 770–778). Piscataway: IEEE.

82. Chen, X., Fang, H., Lin, T. Y., Vedantam, R., Gupta, S., Dollár, P., et al. (2015). Microsoft COCO captions: data collection and evaluation server. arXiv preprint. arXiv:1504.00325.

83. Dosovitskiy, A., Beyer, L., Kolesnikov, A., Weissenborn, D., Zhai, X., Unterthiner, T., et al. (2020). An image is worth 16 × 16 words: transformers for image recognition at scale. In Proceedings of the 9th international conference on learning representations (pp. 1–21). Retrieved November 14, 2024, from https://openreview.net/forum?id=YicbFdNTTy

84. Chen, M., Radford, A., Child, R., Wu, J., Jun, H., Luan, D., et al. (2020). Generative pretraining from pixels. In Proceedings of the 37th international conference on machine learning (pp. 1691–1703). Retrieved November 14, 2024, from http://proceedings.mlr.press/v119/chen20s.html.

85. Kolesnikov, A., Beyer, L., Zhai, X., Puigcerver, J., Yung, J., Gelly, S., et al. (2020). Big transfer (bit): general visual representation learning. In A. Vedaldi, H. Bischof, T. Brox, et al. (Eds.), Proceedings of the 16th European conference on computer vision (pp. 491–507). Cham: Springer.

86. Han, K., Xiao, A., Wu, E., Guo, J., Xu, C., & Wang, Y. (2021). Transformer in transformer. In M. Ranzato, A. Beygelzimer, Y. N. Dauphin, et al. (Eds.), Proceedings of the 35th international conference on neural information processing systems (pp. 15908–15919). Red Hook: Curran Associates.

87. Carion, N., Massa, F., Synnaeve, G., Usunier, N., Kirillov, A., & Zagoruyko, S. (2020). End-to-end object detection with transformers. In A. Vedaldi, H. Bischof, T. Brox, et al. (Eds.), Proceedings of the 16th European conference on computer vision (pp. 213–229). Cham: Springer.

88. Dai, Z., Cai, B., Lin, Y., & Chen, J. (2021). UP-DETR: unsupervised pre-training for object detection with transformers. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition (pp. 1601–1610). Piscataway: IEEE.

89. Zheng, M., Gao, P., Zhang, R., Li, K., Wang, X., Li, H., et al. (2021). End-to-end object detection with adaptive clustering transformer. In Proceedings of the 32nd British machine vision conference (pp. 1–14). Swansea: BMVA Press.

90. Chen, Y., Cao, Y., Hu, H., & Wang, L. (2020). Memory enhanced global-local aggregation for video object detection. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition (pp. 10337–10346). Piscataway: IEEE.

91. Zeng, Y., Fu, J., & Chao, H. (2020). Learning joint spatial-temporal transformations for video inpainting. In A. Vedaldi, H. Bischof, T. Brox, et al. (Eds.), Proceedings of the 16th European conference on computer vision (pp. 528–543). Cham: Springer.

92. Bertasius, G., Wang, H., & Torresani, L. (2021). Is space-time attention all you need for video understanding? In Proceedings of the 38th international conference on machine learning (pp. 813–824). Retrieved November 13, 2024, from http://proceedings.mlr.press/v139/bertasius21a.html.

93. Fox, G. C., Williams, R. D., & Messina, G. C. (1994). Parallel computing works! Amsterdam: Elsevier.

94. Le, H. S., Allauzen, A., & Yvon, F. (2012). Measuring the influence of long range dependencies with neural network language models. In Proceedings of the NAACL-HLT 2012 workshop: will we ever really replace the n-gram model? On the future of language modeling for HLT (pp. 1–10). Stroudsburg: ACL.

95. He, K., Chen, X., Xie, S., Li, Y., Dollár, P., & Girshick, R. (2022). Masked autoencoders are scalable vision learners. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition (pp. 16000–16009). Piscataway: IEEE.

96. Chen, X., Xie, S., & He, K. (2021). An empirical study of training self-supervised vision transformers. In Proceedings of the IEEE/CVF international conference on computer vision (pp. 9640–9649). Piscataway: IEEE.

97. Hendrycks, D., Mazeika, M., Kadavath, S., & Song, D. (2019). Using self-supervised learning can improve model robustness and uncertainty. In H. Wallach, H. Larochelle, A. Beygelzimer, et al. (Eds.), Proceedings of the 33th international conference on neural information processing systems (pp. 15637–15648). Red Hook: Curran Associates.

98. Chen, T., Kornblith, S., Swersky, K., Norouzi, M., & Hinton, G. E. (2020). Big self-supervised models are strong semi-supervised learners. In H. Larochelle, M. Ranzato, R. Hadsell, et al. (Eds.), Proceedings of the 34th international conference on neural information processing systems (pp. 22243–22255). Red Hook: Curran Associates.

99. Parthasarathy, N., Eslami, S. M., Carreira, J., & Henaff, O. (2023). Self-supervised video pretraining yields robust and more human-aligned visual representations. In A. Oh, T. Neumann, A. Globerson, et al. (Eds.), Proceedings of the 37th international conference on neural information processing systems (pp. 65743–65765). Red Hook: Curran Associates.

100. Akbari, H., Yuan, L., Qian, R., Chuang, W. H., Chang, S. F., Cui, Y., et al. (2021). VATT: transformers for multimodal self-supervised learning from raw video, audio and text. In M. Ranzato, A. Beygelzimer, Y. N. Dauphin, et al. (Eds.), Proceedings of the 35th international conference on neural information processing systems (pp. 24206–24221). Red Hook: Curran Associates.

101. Figueiredo, R. B., & Mendes, H. A. (2024). Analyzing information leakage on video object detection datasets by splitting images into clusters with high spatiotemporal correlation. IEEE Access, 12, 47646–47655.

102. Wang, L., Huang, B., Zhao, Z., Tong, Z., He, Y., Wang, Y., et al. (2023). Videomae v2: scaling video masked autoencoders with dual masking. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition (pp. 14549–14560). Piscataway: IEEE.

103. Kirillov, A., Mintun, E., Ravi, N., Mao, H., Rolland, C., Gustafson, L., et al. (2023). Segment anything. In Proceedings of the IEEE/CVF international conference on computer vision (pp. 4015–4026). Piscataway: IEEE.

104. Zou, X., Yang, J., Zhang, H., Li, F., Li, L., Wang, J., et al. (2023). Segment everything everywhere all at once. In A. Oh, T. Neumann, A. Globerson, et al. (Eds.), Proceedings of the 37th international conference on neural information processing systems (pp. 1–13). Red Hook: Curran Associates.

105. Snell, J., Swersky, K., & Zemel, R. (2017). Prototypical networks for few-shot learning. In I. Guyon, U. von Luxburg, S. Bengio, et al. (Eds.), Proceedings of

the 31st international conference on neural information processing systems (pp. 4077–4087). Red Hook: Curran Associates.

106. Xi, T., Sun, Y., Yu, D., Li, B., Peng, N., Zhang, G., et al. (2022). UFO: unified feature optimization. In S. Avidan, G. J. Brostow, M. Cissé, et al. (Eds.), Proceedings of the 17th European conference on computer vision (pp. 472–488). Cham: Springer.

107. Shao, J., Chen, S., Li, Y., Wang, K., Yin, Z., He, Y., et al. (2021). Intern: a new learning paradigm towards general vision. arXiv preprint. arXiv:2111. 08687.

108. Kiela, D., Grave, E., Joulin, A., & Mikolov, T. (2018). Efficient large-scale multi-modal classification. In S. A. McIlraith & K. Q. Weinberger (Eds.), Proceedings of the 32nd AAAI conference on artificial intelligence (pp. 5198–5204). Palo Alto: AAAI Press.

109. Chen, H., Li, Y., & Su, D. (2019). Multi-modal fusion network with multi-scale multi-path and cross-modal interactions for RGB-D salient object detection. Pattern Recognition, 86, 376–385.

110. Antol, S., Agrawal, A., Lu, J., Mitchell, M., Batra, D., Zitnick, C. L., et al. (2015). VQA: visual question answering. In Proceedings of the IEEE international conference on computer vision (pp. 2425–2433). Piscataway: IEEE.

111. Croitoru, F. A., Hondru, V., Ionescu, R. T., & Shah, M. (2023). Diffusion models in vision: a survey. IEEE Transactions on Pattern Analysis and Machine Intelligence, 45(9), 10850–10869.

112. Creswell, A., White, T., Dumoulin, V., Arulkumaran, K., Sengupta, B., & Bharath, A. A. (2018). Generative adversarial networks: an overview. IEEE Signal Processing Magazine, 35(1), 53–65.

113. Nichol, A., Dhariwal, P., Ramesh, A., Shyam, P., Mishkin, P., McGrew, B., et al. (2021). GLIDE: towards photorealistic image generation and editing with text-guided diffusion models. In K. Chaudhuri, S. Jegelka, L. Song, et al. (Eds.), Proceedings of the international conference on machine learning (pp. 16784–16804). Retrieved November 14, 2024, from https://proceedings.mlr.press/v162/nichol22a.html.

114. Radford, A., Kim, J. W., Hallacy, C., Ramesh, A., Goh, G., Agarwal, S., et al. (2021). Learning transferable visual models from natural language supervision. In M. Meila & T. Zhang (Eds.), Proceedings of the 38th international conference on machine learning (pp. 8748–8763). Retrieved November 14, 2024, from http://proceedings.mlr.press/v139/radford21a.html.

115. Ramesh, A., Dhariwal, P., Nichol, A., Chu, C., & Chen, M. (2022). Hierarchical text-conditional image generation with clip latents. arXiv preprint. arXiv: 2204.06125.

116. Rombach, R., Blattmann, A., Lorenz, D., Esser, P., & Ommer, B. (2022). High-resolution image synthesis with latent diffusion models. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition (pp. 10684–10695). Piscataway: IEEE.

117. Ho, J., Jain, A., & Abbeel, P. (2020). Denoising diffusion probabilistic models. In H. Larochelle, M. Ranzato, R. Hadsell, et al. (Eds.), Proceedings of the 34th international conference on neural information processing systems (pp. 6840–6851). Red Hook: Curran Associates.

118. Saharia, C., Chan, W., Saxena, S., Li, L., Whang, J., Denton, E. L., et al. (2022) Photorealistic text-to-image diffusion models with deep language understanding. In S. Koyejo, S. Mohamed, A. Agarwal, et al. (Eds.), Proceedings of the 36th international conference on neural information processing systems (pp. 36479–36494). Red Hook: Curran Associates.

119. Awel, M. A., & Abidi, A. I. (2019). Review on optical character recognition. International Journal of Research in Engineering and Technology, 6(6), 3666–3669.

120. Wang, J., Yang, Z., Hu, X., Li, L., Lin, K., Gan, Z., et al. (2022). GIT: a generative image-to-text transformer for vision and language. arXiv preprint. arXiv: 2205.14100.

121. Wang, W., Lv, Q., Yu, W., Hong, W., Qi, J., Wang, Y., et al. (2023). CogVLM: visual expert for large language models. arXiv preprint. arXiv:2311.03079.

122. Geva, M., Caciularu, A., Wang, K. R., & Goldberg, Y. (2022). Transformer feed-forward layers build predictions by promoting concepts in the vocabulary space. In Y. Goldberg, Z. Kozareva, & Y. Zhang (Eds.), Proceedings of the 2022 conference on empirical methods in natural language processing (pp. 30–45). Stroudsburg: ACL.

123. He, X., Wei, L., Xie, L., & Tian, Q. (2024). Incorporating visual experts to resolve the information loss in multimodal large language models. arXiv preprint. arXiv:2401.03105.

124. Achiam, J., Adler, S., Agarwal, S., Ahmad, L., Akkaya, I., Aleman, F. L., et al. (2023). GPT-4 technical report. arXiv preprint. arXiv:2303.08774.

125. Zhu, D., Chen, J., Shen, X., Li, X., & Elhoseiny, M. (2024). MiniGPT-4: enhancing vision-language understanding with advanced large language models. In Proceedings of the 12th international conference on learning representations (pp. 1–17). Retrieved November 14, 2024, from https://openreview.net/forum?id=1tZbq88f27.

126. Wang, M., Xing, J., & Liu, Y. (2021). ActionCLIP: a new paradigm for video action recognition. arXiv preprint. arXiv:2109.08472.

127. Jia, C., Yang, Y., Xia, Y., Chen, Y. T., Parekh, Z., Pham, H., et al. (2021). Scaling up visual and vision-language representation learning with noisy text supervision. In M. Meila & T. Zhang (Eds.), Proceedings of the 38th international conference on machine learning (pp. 4904–4916). Retrieved November 14, 2024, from http://proceedings.mlr.press/v139/jia21b.html.

128. Li, J., Li, D., Xiong, C., & Hoi, S. (2022). BLIP: bootstrapping language-image pre-training for unified vision-language understanding and generation. In K. Chaudhuri, S. Jegelka, L. Song, et al. (Eds.). International conference on machine learning (pp. 12888–12900). Retrieved November 14, 2024, from https://proceedings.mlr.press/v162/li22n.html.

129. Wang, W., Bao, H., Dong, L., Bjorck, J., Peng, Z., Liu, Q., et al. (2022). Image as a foreign language: BEiT pretraining for all vision and vision-language tasks. arXiv preprint. arXiv:2208.10442.

130. Chen, X., Wang, X., Changpinyo, S., Piergiovanni, A. J., Padlewski, P., Salz, D., et al. (2022). PaLI: a jointly-scaled multilingual language-image model. In Proceedings of the 12th international conference on learning representations. (pp. 1–33). Retrieved November 12, 2024, from https://openreview.net/forum?id=mWVoBz4W0u.

131. Dehghani, M., Djolonga, J., Mustafa, B., Padlewski, P., Heek, J., Gilmer, J., et al. (2023). Scaling vision transformers to 22 billion parameters. In A. Krause, E. Brunskill, K. Cho, et al. (Eds.), Proceedings of the international conference on machine learning (pp. 7480–7512). Retrieved November 14, 2024, from https://proceedings.mlr.press/v202/dehghani23a.html.

132. Driess, D., Xia, F., Sajjadi, M. S., Lynch, C., Chowdhery, A., Ichter, B., et al. (2023). PaLM-E: an embodied multimodal language model. In A. Krause, E. Brunskill, K. Cho, et al. (Eds.), Proceedings of the international conference on machine learning (pp. 8469–8488). Retrieved November 14, 2024, from https://proceedings.mlr.press/v202/driess23a.html.

133. Liu, H., Li, C., Wu, Q., & Lee, Y. J. (2023). Visual instruction tuning. In A. Oh, T. Neumann, A. Globerson, et al. (Eds.), Proceedings of the 37th international conference on neural information processing systems (pp. 1–25). Red Hook: Curran Associates.

134. Liu, H., Li, C., Li, Y., & Lee, Y. J. (2024). Improved baselines with visual instruction tuning. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition (pp. 26296–26306). Piscataway: IEEE.

135. Li, C., Wong, C., Zhang, S., Usuyama, N., Liu, H., Yang, J., et al. (2023). LLaVA-Med: training a large language-and-vision assistant for biomedicine in one day. In A. Oh, T. Neumann, A. Globerson, et al. (Eds.), Proceedings of the 37th international conference on neural information processing systems (pp. 1–17). Red Hook: Curran Associates.

136. Dai, W., Li, J., Li, D., Tiong, A. M., Zhao, J., Wang, W., et al. (2023). InstructBLIP: towards general-purpose vision-language models with instruction tuning (pp. 1–17). Red Hook: Curran Associates.

137. Bai, J., Bai, S., Yang, S., Wang, S., Tan, S., Wang, P., et al. (2023). Qwen-VL: a frontier large vision-language model with versatile abilities. arXiv preprint. arXiv:2308.12966.

138. Chen, Z., Wu, J., Wang, W., Su, W., Chen, G., Xing, S., et al. (2023). Intern VL: scaling up vision foundation models and aligning for generic visual-linguistic tasks. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition (pp. 24185–24198). Piscataway: IEEE.

139. Xia, Y., Huang, H., Zhu, J., & Zhao, Z. (2023). Achieving cross modal generalization with multimodal unified representation. In A. Oh, T. Neumann, A. Globerson, et al. (Eds.), Proceedings of the 37th international conference on neural information processing systems (pp. 1–15). Red Hook: Curran Associates.

140. Joshi, G., Walambe, R., & Kotecha, K. (2021). A review on explainability in multimodal deep neural nets. IEEE Access, 9, 59800–59821.

141. Wang, M., Lu, S., Zhu, D., Lin, J., & Wang, Z. (2018). A high-speed and low-complexity architecture for softmax function in deep learning. In Proceedings of the IEEE Asia Pacific conference on circuits and systems (pp. 223–226). Piscataway: IEEE.

142. Hanin, B. (2018). Which neural net architectures give rise to exploding and vanishing gradients? In S. Bengio, H. Wallach, H. Larochelle, et al. (Eds.), Proceedings of the 32nd international conference on neural

information processing systems (pp. 580–589). Red Hook: Curran Associates.

143. Han, Z., Gao, C., Liu, J., & Zhang, S. Q. (2024). Parameter-efficient fine-tuning for large AI models: a comprehensive survey. arXiv preprint. arXiv:2403.14608.

144. Loquercio, A., Segu, M., & Scaramuzza, D. (2020). A general framework for uncertainty estimation in deep learning. IEEE Robotics and Automation Letters, 5(2), 3153–3160.

145. Li, X. L., & Liang, P. (2021). Prefix-tuning: optimizing continuous prompts for generation. In C. Zong, F. Xia, W. Li, et al. (Eds.), Proceedings of the 59th annual meeting of the Association for Computational Linguistics and the 11th international joint conference on natural language processing (pp. 4582–4597). Stroudsburg: ACL.

146. Liu, X., Ji, K., Fu, Y., Tam, W. L., Du, Z., Yang, Z., et al. (2021). P-tuning v2: prompt tuning can be comparable to fine-tuning universally across scales and tasks. arXiv preprint. arXiv:2110.07602.

147. Rasley, J., Rajbhandari, S., Ruwase, O., & He, Y. (2020). DeepSpeed: system optimizations enable training deep learning models with over 100 billion parameters. In R. Gupta, Y. Liu, J. Tang, et al. (Eds.), Proceedings of the 26th ACM SIGKDD international conference on knowledge discovery & data mining (pp. 3505–3506). New York: ACM.

148. Taskaya-Temizel, T., & Casey, M. C. (2005). A comparative study of autoregressive neural network hybrids. Neural Networks, 18(5–6), 781–789.

149. Zhang, Y., & Yang, Q. (2021). A survey on multi-task learning. IEEE Transactions on Knowledge and Data Engineering, 34(12), 5586–5609.

150. Ivison, H., Bhagia, A., Wang, Y., Hajishirzi, H., & Peters, M. (2023). HINT: hypernetwork instruction tuning for efficient zero-& few-shot generalisation. In A. Rogers, J. L. Boyd-Graber, & N. Okazaki (Eds.), Proceedings of the 61st annual meeting of the Association for Computational Linguistics (pp. 11272–11288). Stroudsburg: ACL.

151. Lv, K., Yang, Y., Liu, T., Gao, Q., Guo, Q., & Qiu, X. (2024). Full parameter fine-tuning for large language models with limited resources. In L.-W. Ku, A. Martins, & V. Srikumar (Eds.), Proceedings of the 62nd annual meeting of the Association for Computational Linguistics (pp. 8187–8198). Stroudsburg: ACL.

152. Shen, L., Sun, Y., Yu, Z., Ding, L., Tian, X., & Tao, D. (2023). On efficient training of large-scale deep learning models: a literature review. arXiv preprint. arXiv:2304.03589.

153. Dai, J. J., Wang, Y., Qiu, X., Ding, D., Zhang, Y., Wang, Y., et al. (2019). BigDL: a distributed deep learning framework for big data. In Proceedings of the ACM symposium on cloud computing (pp. 50–60). New York: ACM.

154. Sherstinsky, A. (2020). Fundamentals of recurrent neural network (RNN) and long short-term memory (LSTM) network. Physica D. Nonlinear Phenomena, 404, 132306.

155. Pang, B., Nijkamp, E., & Wu, Y. N. (2020). Deep learning with tensorflow: a review. Journal of Educational and Behavioral Statistics, 45(2), 227–248.

156. Ketkar, N., & Moolayil, J. (2021). Deep learning with Python: learn best practices of deep learning models with PyTorch. Berkeley: Apress.

157. Ketkar, N. (2017). Deep learning with Python: a hands-on introduction. Berkeley: Apress.

158. Richardson, J., McLeod, S., Flora, K., Sauers, N., Kannan, S., & Sincar, M. (2013). Large-scale 1: 1 computing initiatives: an open access database. International Journal of Education and Development Using ICT, 9(1), 4–18.

159. Sapkota, A., & Boult, T. E. (2013). Large scale unconstrained open set face database. In Proceedings of the IEEE 6th international conference on biometrics: theory, applications and systems (pp. 1–8). Piscataway: IEEE.

160. Igarashi, Y., Nakatsu, N., Yamashita, T., Ono, A., Ohno, Y., Urushidani, T., et al. (2015). Open TG-GATEs: a large-scale toxicogenomics database. \*Nucleic Acids Research\*, 43, 921–927.

161. Bandy, J., & Vincent, N. (2021). Addressing" documentation debt" in machine learning research: a retrospective datasheet for bookcorpus. arXiv preprint. arXiv:2105.05241.

162. Deter, D., Wang, C., Cook, A., & Perry, N. K. (2020). Simulating the autonomous future: a look at virtual vehicle environments and how to validate simulation using public data sets. IEEE Signal Processing Magazine, 38(1), 111–121.

163. Endres, M., Mannarapotta Venugopal, A., & Tran, T. S. (2022). Synthetic data generation: a comparative study. In B. C. Desai & P. Z. Revesz (Eds.), Proceedings of the 26th international database engineered applications symposium (pp. 94–102). New York: ACM.

164. Dandekar, A., Zen, R. A., & Bressan, S. (2018). A comparative study of synthetic dataset generation techniques. In S. Hartmann, H. Ma, A. Hameurlain, et al. (Eds.), Proceedings of the 29th international conference on database and expert systems applications (pp. 387–395). Cham: Springer.

165. Gao, C., Jajodia, S., Pugliese, A., & Subrahmanian, V. S. (2024). FakeDB: generating fake synthetic databases. IEEE Transactions on Dependable and Secure Computing, 21(6), 5553–5564.

166. Nichol, A. Q., Dhariwal, P., Ramesh, A., Shyam, P., Mishkin, P., McGrew, B., et al. (2024). GLIDE: towards photorealistic image generation and editing with text-guided diffusion models. In K. Chaudhuri, S. Jegelka, L. Song, et al. (Eds.), Proceedings of the international conference on machine learning (pp. 16784–16804). Retrieved November 12, 2024, from https://proceedings.mlr.press/v162/nichol22a.html.

167. Sharir, O., Peleg, B., & Shoham, Y. (2020). The cost of training NLP models: a concise overview. arXiv preprint. arXiv:2004.08900.

168. Chen, X., Wang, G., Zhou, Y., & Li, R. (2021). The high-quality development of China's publication printing industry from an environmental perspective. Journal of Global Information Management, 30(6), 1–18.

169. Shoeybi, M., Patwary, M., Puri, R., LeGresley, P., Casper, J., & Catanzaro, B. (2019). Megatron-LM: training multi-billion parameter language models using model parallelism. arXiv preprint. arXiv:1909.08053.

170. Wang, G., Qin, H., Jacobs, S. A., Holmes, C., Rajbhandari, S., Ruwase, O., et al. (2023). Zero++: extremely efficient collective communication for giant model training. arXiv preprint. arXiv:2306.10209.

171. Ren, J., Rajbhandari, S., Aminabadi, R. Y., Ruwase, O., Yang, S., Zhang, M., et al. (2021). Zero-offload: democratizing billion-scale model training. In I. Calciu & G. Kuenning (Eds.), Proceedings of the 2021 USENIX annual technical conference (pp. 551–564). Berkeley: USENIX Association.

172. Smith, S., Patwary, M., Norick, B., LeGresley, P., Rajbhandari, S., Casper, J., et al. (2022). Using deepspeed and megatron to train megatron-turing nlg 530b, a large-scale generative language model. arXiv preprint. arXiv:2201.11990.

173. Le Scao, T., Fan, A., Akiki, C., Pavlick, E., Ilić, S., Hesslow, D., et al. (2023). Bloom: a 176b-parameter open-access multilingual language model. arXiv preprint. arXiv:2211.05100.

174. Peng, Y., Bao, Y., Chen, Y., Wu, C., & Guo, C. (2018). Optimus: an efficient dynamic resource scheduler for deep learning clusters. In R. Oliveira, P. Felber, & Y. C. Hu (Eds.), Proceedings of the 13th EuroSys conference (pp. 1–14). New York: ACM.

175. Ding, Y., Jiang, W., Lou, Q., Liu, J., Xiong, J., Hu, X. S., et al. (2020). Hardware design and the competency awareness of a neural network. Nature Electronics, 3(9), 514–523.

176. Boullosa, D., Claudino, J. G., Fernandez-Fernandez, J., Bok, D., Loturco, I., Stults-Kolehmainen, M., et al. (2023). The fine-tuning approach for training monitoring. International Journal of Sports Physiology and Performance, 12, 1374–1379.

177. Montesinos López, O. A., Montesinos López, A., & Crossa, J. (2022). Multivariate statistical machine learning methods for genomic prediction. Cham: Springer.

178. Stoll, S., Hadfield, S., & Bowden, R. (2020). Signsynth: data-driven sign language video generation. In A. Vedaldi, H. Bischof, T. Brox, et al. (Eds.), The 16th European conference on computer vision (pp. 353–370). Cham: Springer.

179. Luo, Y., Yu, X., Yang, D., & Zhou, B. (2023). A survey of intelligent transmission line inspection based on unmanned aerial vehicle. Artificial Intelligence Review, 56(1), 173–201.

180. Wu, J., Williams, K. M., Chen, H. H., Khabsa, M., Caragea, C., Tuarob, S., et al. (2015). Citeseerx: AI in a digital library search engine. AI Magazine, 36(3), 35–48.

181. Kim, S. Y., Fan, Z., Noller, Y., & Roychoudhury, A. (2024). Codexity: secure Al-assisted code generation. arXiv preprint. arXiv:2405.03927.

182. Aminabadi, R. Y., Rajbhandari, S., Awan, A. A., Li, C., Li, D., Zheng, E., et al. (2022). Deepspeed-inference: enabling efficient inference of transformer models at unprecedented scale. In Proceedings of the international conference for high performance computing, networking, storage and analysis (pp. 1–15). Piscataway: IEEE.

183. Frantar, E., Ashkboos, S., Hoefler, T., & Alistarh, D. (2022). GPTQ: accurate post-training quantization for generative pre-trained transformers. arXiv preprint. arXiv:2210.17323.

184. Qin, H., Ma, X., Zheng, X., Li, X., Zhang, Y., Liu, S., et al. (2024). Accurate LoRA-finetuning quantization of LLMs via information retention. In Proceedings of the 41st international conference on machine learning (pp.

1–19). Retrieved November 14, 2024, from https://openreview.net/forum?id=jQ92egz5Ym.

185. Huang, W., Liu, Y., Qin, H., Li, Y., Zhang, S., Liu, X., et al. (2024). BiLLM: pushing the limit of post-training quantization for LLMs. In Proceedings of the 41st international conference on machine learning (pp. 1–20). Retrieved November 14, 2024, from https://openreview.net/forum?id=qOl2WWOqFq.

186. Pan, X., Zhang, M., Ji, S., & Yang, M. (2020). Privacy risks of general-purpose language models. In Proceedings of the IEEE symposium on security and privacy (pp. 1314–1331). Piscataway: IEEE.

187. Nagrani, A., Yang, S., Arnab, A., Jansen, A., Schmid, C., & Sun, C. (2021). Attention bottlenecks for multimodal fusion. In M. Ranzato, A. Beygelzimer, Y. N. Dauphin, et al. (Eds.), Proceedings of the 35th international conference on neural information processing systems (pp. 14200–14213). Red Hook: Curran Associates.

188. De Lange, M., Aljundi, R., Masana, M., Parisot, S., Jia, X., Leonardis, A., et al. (2021). A continual learning survey: defying forgetting in classification tasks. IEEE Transactions on Pattern Analysis and Machine Intelligence, 44(7), 3366–3385.

189. van de Ven, G. M., Tuytelaars, T., & Tolias, A. S. (2022). Three types of incremental learning. Nature Machine Intelligence, 4(12), 1185–1197.

190. Liu, X., Zhang, F., Hou, Z., Mian, L., Wang, Z., Zhang, J., et al. (2021). Self-supervised learning: generative or contrastive. IEEE Transactions on Knowledge and Data Engineering, 35(1), 857–876.

191. Zhou, Z. H. (2018). A brief introduction to weakly supervised learning. National Science Review, 5(1), 44–53.

192. Shah, V., & Konda, S. R. (2021). Neural networks and explainable AI: bridging the gap between models and interpretability. International Journal of Computer Science and Technology, 5(2), 163–176.

193. Li, Y., Du, M., Song, R., Wang, X., & Wang, Y. (2023). A survey on fairness in large language models. arXiv preprint. arXiv:2308.10149.

194. Chen, J., & Ran, X. (2019). Deep learning with edge computing: a review. Proceedings of the IEEE, 107(8), 1655–1674.

## Publisher's Note

Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

## Submit your manuscript to a SpringerOpen $^{®}$ journal and benefit from:

▶ Convenient online submission

▶ Rigorous peer review

▶ Open access: articles freely available online

▶ High visibility within the field

▶ Retaining the copyright to your article

Submit your next manuscript at ▶ springeropen.com