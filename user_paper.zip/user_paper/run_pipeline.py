"""Run MinerU -> Baidu OCR -> chunk build -> RAGFlow import."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Sequence

from pipeline_common import sanitize_name, utc_now, write_json


HERE = Path(__file__).resolve().parent


def run_stage(
    name: str,
    command: Sequence[str],
    *,
    accepted_codes: set[int] | None = None,
) -> int:
    accepted = accepted_codes or {0}
    print(f"\n=== {name} ===", flush=True)
    completed = subprocess.run(list(command), check=False)
    if completed.returncode not in accepted:
        raise RuntimeError(f"Stage {name} failed with exit code {completed.returncode}")
    return completed.returncode


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pdf", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, default=Path("data/user_paper_runs"))
    parser.add_argument("--run-name")
    parser.add_argument("--mineru-dir", type=Path)
    parser.add_argument("--fallback-mineru-dir", type=Path)
    parser.add_argument("--skip-baidu", action="store_true")
    parser.add_argument("--skip-vl", action="store_true")
    parser.add_argument("--strict-specialized", action="store_true")
    parser.add_argument("--force-ocr", action="store_true")
    parser.add_argument("--skip-ragflow", action="store_true")
    parser.add_argument("--ragflow-base-url", default="http://localhost:9380/api/v1")
    parser.add_argument("--dataset-id")
    parser.add_argument("--dataset-name", default="user_papers_private_v1")
    parser.add_argument("--user-id", default="local-user")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    pdf = args.pdf.resolve()
    if not pdf.exists():
        raise SystemExit(f"PDF not found: {pdf}")
    run_name = args.run_name or sanitize_name(pdf.stem.lower())
    run_root = (args.output_root / run_name).resolve()
    mineru_clean_dir = run_root / "01_mineru_clean"
    ocr_dir = run_root / "02_baidu_ocr"
    chunks_dir = run_root / "03_chunks"
    ragflow_dir = run_root / "04_ragflow"
    run_root.mkdir(parents=True, exist_ok=True)

    mineru_command = [
        sys.executable,
        str(HERE / "mineru_clean.py"),
        "--pdf",
        str(pdf),
        "--output-dir",
        str(mineru_clean_dir),
    ]
    if args.mineru_dir:
        mineru_command.extend(["--mineru-dir", str(args.mineru_dir.resolve())])
    try:
        run_stage("MinerU acquisition and clean", mineru_command)
    except Exception:
        if not args.fallback_mineru_dir or args.mineru_dir:
            raise
        print("MinerU cloud acquisition failed; using the configured local fallback.")
        run_stage(
            "MinerU local fallback clean",
            [
                sys.executable,
                str(HERE / "mineru_clean.py"),
                "--pdf",
                str(pdf),
                "--output-dir",
                str(mineru_clean_dir),
                "--mineru-dir",
                str(args.fallback_mineru_dir.resolve()),
            ],
        )

    if not args.skip_baidu:
        ocr_command = [
            sys.executable,
            str(HERE / "baidu_ocr.py"),
            "--media-jsonl",
            str(mineru_clean_dir / "media_objects.jsonl"),
            "--output-dir",
            str(ocr_dir),
        ]
        if args.skip_vl:
            ocr_command.append("--skip-vl")
        if args.strict_specialized:
            ocr_command.extend(["--strict-specialized", "--fail-fast"])
        if args.force_ocr:
            ocr_command.append("--force")
        run_stage("Baidu OCR enrichment", ocr_command, accepted_codes={0, 2})
    else:
        ocr_dir.mkdir(parents=True, exist_ok=True)

    run_stage(
        "Second clean and structured chunks",
        [
            sys.executable,
            str(HERE / "second_clean.py"),
            "--mineru-clean-dir",
            str(mineru_clean_dir),
            "--ocr-dir",
            str(ocr_dir),
            "--output-dir",
            str(chunks_dir),
        ],
    )

    if not args.skip_ragflow:
        import_command = [
            sys.executable,
            str(HERE / "ragflow_import.py"),
            "--chunks-dir",
            str(chunks_dir),
            "--state-dir",
            str(ragflow_dir),
            "--base-url",
            args.ragflow_base_url,
            "--dataset-name",
            args.dataset_name,
            "--user-id",
            args.user_id,
        ]
        if args.dataset_id:
            import_command.extend(["--dataset-id", args.dataset_id])
        run_stage("RAGFlow manual import", import_command)

    summary = {
        "run_name": run_name,
        "pdf": str(pdf),
        "run_root": str(run_root),
        "mineru_clean_dir": str(mineru_clean_dir),
        "ocr_dir": str(ocr_dir),
        "chunks_dir": str(chunks_dir),
        "ragflow_dir": str(ragflow_dir) if not args.skip_ragflow else None,
        "completed_at": utc_now(),
    }
    write_json(run_root / "pipeline_summary.json", summary)
    print("\n" + json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
