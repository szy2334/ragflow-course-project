# 用户论文 PDF 摄取流水线

本目录实现以下阶段：

1. `mineru_clean.py`：调用 MinerU 或读取已有 MinerU 产物，生成稳定业务 Block 和媒体对象。
2. `baidu_ocr.py`：按图片、图表、表格调用百度 OCR，并保存原始响应与归一化结果。
3. `second_clean.py`：生成正文、摘要、公式、表格、图片和参考文献等结构化 Chunk。
4. `ragflow_import.py`：以 manual Chunk 方式导入 RAGFlow，保存业务 Chunk 与 RAGFlow Chunk 映射。
5. `run_pipeline.py`：串联上述阶段。

凭据只从运行时环境变量读取：

```text
MINERU_TOKEN
BAIDU_OCR_API_KEY
BAIDU_OCR_SECRET_KEY
RAGFLOW_API_KEY
```

不要将真实密钥写入源码或提交到 Git。

示例：

```powershell
python data_pipeline/user_paper/run_pipeline.py `
  --pdf UMAP.pdf `
  --output-root data/user_paper_runs `
  --fallback-mineru-dir MinerU_data/UMAP.pdf-dac2a9bc-648b-4f1f-b943-012970808954 `
  --strict-specialized `
  --force-ocr `
  --dataset-name user_papers_private_v1 `
  --user-id local-user
```

`--strict-specialized` 要求百度表格识别 V2 与 PaddleOCR-VL 均成功，任何专项接口失败都会终止，不进入普通 OCR 或 MinerU 表格降级路径。

主要产物：

```text
01_mineru_clean/document.json
01_mineru_clean/blocks.jsonl
01_mineru_clean/media_objects.jsonl
02_baidu_ocr/ocr_results.jsonl
03_chunks/chunks.jsonl
03_chunks/ragflow_chunks.jsonl
03_chunks/quality_report.json
04_ragflow/chunk_mapping.jsonl
04_ragflow/import_summary.json
```
